/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


/**
 * JUnit testing for Controller
 * 
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 */
public class ControllerTest {
	static Model model;
	static Controller controller;
	static int timing = 8;
    static boolean play;
	static boolean running;
	View view;
	static boolean run;
    public static Collection<DynamicGridItem> deathQueue;
	static Bullfrog bfrog01, bfrog02;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		model= new Model(50,50);
		controller = new Controller(model, false);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		model = null;
		controller = null;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		run = false;
		play = false;
		running = false;
		bfrog01 = new Bullfrog(50,60);
		bfrog02 = new Bullfrog(40,50);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		bfrog01 = null;
	    bfrog02 = null;
	}

	/**
	 * Test method for {@link Controller#Controller(Model)}.
	 */
	@Test
	public final void testController() {
		assertNotNull("controller constructor failed",controller);
	}

	/**
	 * Test method for {@link Controller#togglePlay()}.
	 */
	@Test
	public final void testTogglePlay() {
		boolean initPlay = Controller.getPlay();
		Controller.togglePlay();
		assertNotSame("Play button did not toggle", initPlay, play);
	}

	/**
	 * Test method for {@link Controller#cleanupBodies()}.
	 */
	@Test
	public final void testCleanupBodies() {
		deathQueue = new ArrayList<DynamicGridItem>();
		Model.addToDeathQueue(bfrog01);
		Model.addToDeathQueue(bfrog02);
		Controller.cleanupBodies();
		assertTrue("items did not clear",deathQueue.isEmpty());
	}

}
