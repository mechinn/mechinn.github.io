/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import static org.junit.Assert.*;

import java.awt.Point;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * JUnit testing for DynamicGridItem
 * 
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 */
public class DynamicGridItemTest {
	static Bullfrog bfrog01, bfrog02;
	static Fly fly01;
	static Model model;
    /**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		model = new Model(50,50);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		model = null;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		bfrog01 = new Bullfrog(50,60);
		bfrog02 = new Bullfrog(40,50);
		fly01 = new Fly(60,70);
		new ArrayList<DynamicGridItem>();
		Model.addItem(bfrog01);
		Model.addItem(bfrog02);
		Model.addItem(fly01);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		bfrog01 = null;
	    bfrog02 = null;
	    fly01 = null;
	}

	/**
	 * Test method for {@link DynamicGridItem#DynamicGridItem(int, int, int, int, int, java.lang.String, int)}.
	 */
	@Test
	public final void testDynamicGridItem() {
		assertNotNull("DynamicGridItem constructor failed",bfrog01);
		assertNotNull("DynamicGridItem constructor failed",bfrog02);
		assertNotNull("DynamicGridItem constructor failed",fly01);
	}

	/**
	 * Test method for {@link DynamicGridItem#decreaseActionCounter()}.
	 */
	@Test
	public final void testDecreaseActionCounter() {
		int action = bfrog01.getActionCounter();
		bfrog01.decreaseActionCounter();
		assertTrue("actionCounter did not decrease", action-1 == bfrog01.getActionCounter());
	}

	/**
	 * Test method for {@link DynamicGridItem#resetChasingFood()}.
	 */
	@Test
	public final void testResetChasingFood() {
		bfrog01.setChasingFood();
		bfrog01.resetChasingFood();
		assertFalse("testResetChasingFood failed", bfrog01.getChasing());
	}

	/**
	 * Test method for {@link DynamicGridItem#resetChasingMate()}.
	 */
	@Test
	public final void testResetChasingMate() {
		bfrog01.setChasingMate();
		bfrog01.resetChasingMate();
		assertFalse("testResetChasingMate failed", bfrog01.getChasingMate());
	}

	/**
	 * Test method for {@link DynamicGridItem#isAlive()}.
	 */
	@Test
	public final void testIsAlive() {
		assertTrue("sorry, your animal is dead", bfrog01.isAlive());
		assertTrue("sorry, your animal is dead", bfrog02.isAlive());
		assertTrue("sorry, your animal is dead", fly01.isAlive());
	}

	/**
	 * Test method for {@link DynamicGridItem#incrementAge()}.
	 */
	@Test
	public final void testIncrementAge() {
		int age = bfrog01.getAge();
		bfrog01.incrementAge();
		assertTrue("age did not increase", age+1 == bfrog01.getAge());
		assertFalse("age did not increase", age == bfrog01.getAge());
	}

	/**
	 * Test method for {@link DynamicGridItem#genRand(int)}.
	 */
	@Test
	public final void testGenRand() {
		int range = 10;
		int range02 = Bullfrog.genRand(range);
		assertFalse("Random number generator did not work", range == range02);
	}

	/**
	 * Test method for {@link DynamicGridItem#increaseHunger()}.
	 */
	@Test
	public final void testIncreaseHunger() {
		int hunger = bfrog01.getHunger();
		bfrog01.increaseHunger();
		assertTrue("hunger did not increase", hunger+1 == bfrog01.getHunger());
		bfrog02.increaseHunger();
		assertFalse("hunger did not increase", hunger == bfrog02.getHunger());
		
	}

	/**
	 * Test method for {@link DynamicGridItem#kill()}.
	 */
	@Test
	public final void testKill() {
		bfrog01.kill();
		assertFalse("animal somehow survived", bfrog01.isAlive());
		fly01.kill();
		assertFalse("animal somehow survived", fly01.isAlive());
	}

	/**
	 * Test method for {@link DynamicGridItem#findMate()}.
	 */
	@Test
	public final void testFindMate() {
		bfrog01.setLoc(50, 50);
		bfrog02.setLoc(60, 60);
		bfrog01.setChasingMate();
		assertTrue("animal has not found a mate", bfrog01.findMate());
	}

	/**
	 * Test method for {@link DynamicGridItem#findPrey()}.
	 */
	@Test
	public final void testFindPrey() {
		Point frogLoc = bfrog01.getLoc();
		fly01.setLoc(frogLoc.x+5, frogLoc.y);
		assertTrue("animal is not hunting", bfrog01.findPrey());
		assertFalse("animal is hunting", fly01.findPrey());
	}

	/**
	 * Test method for {@link DynamicGridItem#changeGoal()}.
	 */
	@Test
	public final void testChangeGoal() {
		fly01.setGoal(50, 30);
		Point p = fly01.getGoal();
		fly01.setHungry();
		fly01.changeGoal();
		assertSame("goal has been changed", p, fly01.getGoal());
	}

	/**
	 * Test method for {@link DynamicGridItem#updateLabelText()}.
	 */
	@Test
	public final void testUpdateLabelText() {
		String s = bfrog01.getAction();
		bfrog01.setChasingMate();
		bfrog01.updateLabelText();
		assertNotSame("labelText did not change", s, bfrog01.getNewAction());
	}

	/**
	 * Test method for {@link DynamicGridItem#distance(java.awt.Point, double, double)}.
	 */
	@Test
	public final void testDistancePointDoubleDouble() {
		Point p = new Point(5,6); //x1, y1
		double x2 = 6;
		double y2 = 7;
		double ans = (Math.sqrt(Math.pow(x2-p.x,2.0) + Math.pow(y2-p.y,2.0)));
		assertTrue("incorrect result", ans == bfrog01.distance(p, x2, y2));
	}

	/**
	 * Test method for {@link DynamicGridItem#distance(java.awt.Point, java.awt.Point)}.
	 */
	@Test
	public final void testDistancePointPoint() {
		Point p = new Point(5,6); //x1, y1
		Point p2 = new Point(4,5); //x2, y2
		double ans = (Math.sqrt(Math.pow(p2.x-p.x,2.0) + Math.pow(p2.y-p.y,2.0)));
		assertTrue("incorrect result", ans == bfrog01.distance(p, p2));
	}

	/**
	 * Test method for {@link DynamicGridItem#nextMove()}.
	 */
	@Test
	public final void testNextMove() {
		int m = bfrog01.getMove();
		bfrog01.nextMove();
		assertFalse("next move failed", m == bfrog01.getMove());
		assertTrue("next move failed", m != bfrog01.getMove());
	}

	/**
	 * Test method for {@link DynamicGridItem#isValidMove(int)}.
	 */
	@Test
	public final void testIsValidMove() {
		int m = bfrog01.getMove();
		assertTrue("Not a valid move",bfrog01.isValidMove(m++));
		fly01.setMove(3);
		assertFalse("Not a valid move",fly01.isValidMove(0));
		assertFalse("Not a valid move",fly01.isValidMove(1));
		assertTrue("Not a valid move",fly01.isValidMove(2)); //valid
		assertFalse("Not a valid move",fly01.isValidMove(3));
		assertTrue("Not a valid move",fly01.isValidMove(4)); //valid
		assertFalse("Not a valid move",fly01.isValidMove(5));
		assertFalse("Not a valid move",fly01.isValidMove(6));
		
	}

	/**
	 * Test method for {@link DynamicGridItem#isOutsideTrees(int, int)}.
	 */
	@Test
	public final void testIsOutsideTrees() {
		assertTrue("Stuck in the trees", bfrog01.isOutsideTrees(300, 400));
	}

	/**
	 * Test method for {@link DynamicGridItem#moveItem()}.
	 */
	@Test
	public final void testMoveItem() {
		bfrog01.setLoc(50, 60);
		Point p = bfrog01.getLoc();
		bfrog01.setMove(3);
		bfrog01.moveItem();
		bfrog01.nextMove();
		assertFalse("item not moved", p.x != bfrog01.getLoc().x);
	}

	/**
	 * Test method for {@link DynamicGridItem#goalReached()}.
	 */
	@Test
	public final void testGoalReached() {
		Point p = bfrog01.getGoal();
		bfrog01.setGoal(p.x+50, p.y+50);
		assertFalse("the goal was reached", bfrog01.goalReached());
		
	}

	/**
	 * Test method for {@link DynamicGridItem#moveAction()}.
	 */
	@Test
	public final void testMoveAction() {
		int picIndex = bfrog01.getPicIndex();
		int hunger = bfrog01.getHunger();
		String action = bfrog01.getAction();
		int age = bfrog01.getAge();
		bfrog01.moveAction();
		assertTrue("picIndex did not increase", bfrog01.getPicIndex() == picIndex + 1);
		assertTrue("hunger level did not increase", bfrog01.getHunger() == hunger + 1);
		assertFalse("action was not changed", bfrog01.getNewAction() == action);
		assertTrue("age was not increased", bfrog01.getAge() == age + 1);
	}

	/**
	 * Test method for {@link DynamicGridItem#chase(DynamicGridItem)}.
	 */
	@Test
	public final void testChase() {
		bfrog01.setLoc(30, 40);
		fly01.setLoc(40, 50);
		bfrog01.chase(fly01);
		assertSame("prey has not been set", bfrog01.getPrey(), fly01);
		assertTrue("animal is not chasing prey", bfrog01.getChasing());
		assertSame("goal is not to hunt prey", bfrog01.getGoal().x, fly01.getXCoord());
		assertSame("goal is not to hunt prey", bfrog01.getGoal().y, fly01.getYCoord());
	}

	/**
	 * Test method for {@link DynamicGridItem#attack(DynamicGridItem)}.
	 */
	@Test
	public final void testAttack() {
		bfrog01.setLoc(30, 40);
		int health = fly01.getHealth();
		fly01.setLoc(35, 45);
		bfrog01.attack(fly01);
		assertTrue("attack failed", fly01.getHealth()<health);
	}

	/**
	 * Test method for {@link DynamicGridItem#toString()}.
	 */
	@Test
	public final void testToString() {
		assertEquals("toString failed", bfrog01.toString(), "Bullfrog"+bfrog01.getIDnum());
	}

}
