/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * JUnit testing for Model
 * 
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 */
public class ModelTest {
	static int height;
    static int width;
    static int i = 0;
    private static Collection<DynamicGridItem> items;
    static public Collection<DynamicGridItem> birthQueue;
    public static Collection<DynamicGridItem> deathQueue;
    private static Collection<DynamicGridItem> addQueue;
    static Bullfrog bfrog01, bfrog02;
	static Model model;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		model = new Model(50,50);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		model = null;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		items = new ArrayList<DynamicGridItem>();
		birthQueue = new ArrayList<DynamicGridItem>();
		deathQueue = new ArrayList<DynamicGridItem>();
		addQueue = new ArrayList<DynamicGridItem>();
		bfrog01 = new Bullfrog(50,60);
		bfrog02 = new Bullfrog(40,50);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		items = null;
		birthQueue = null;
	    deathQueue = null;
	    addQueue= null;
	    bfrog01 = null;
	    bfrog02 = null;
	}

	/**
	 * Test method for {@link Model#Model(int, int)}.
	 */
	@Test
	public final void testModel() {
		assertNotNull("model constructor failed",model);
	}
	
	/**
	 * Test method for {@link Model#addItem(DynamicGridItem)}.
	 */
	@Test
	public final void testAddItem() {
		assertTrue("item did not add correctly",Model.addItem(bfrog01));
		assertTrue("item did not add correctly",Model.addItem(bfrog02));
	}

	/**
	 * Test method for {@link Model#addToBirthQueue(DynamicGridItem)}.
	 */
	@Test
	public final void testAddToBirthQueue() {
		assertTrue("item did not add to birth queue",Model.addToBirthQueue(bfrog01));
		assertTrue("item did not add to birth queue",Model.addToBirthQueue(bfrog02));
	}

	/**
	 * Test method for {@link Model#addToDeathQueue(DynamicGridItem)}.
	 */
	@Test
	public final void testAddToDeathQueue() {
		assertTrue("item did not add to death queue",Model.addToDeathQueue(bfrog01));
		assertTrue("item did not add to death queue",Model.addToDeathQueue(bfrog02));
	}

	/**
	 * Test method for {@link Model#doClear()}.
	 */
	@Test
	public final void testDoClear() {
		Model.addItem(bfrog01);
		Model.addItem(bfrog02);
		Model.addToBirthQueue(bfrog01);
		Model.addToBirthQueue(bfrog02);
		Model.addToDeathQueue(bfrog01);
		Model.addToDeathQueue(bfrog02);
		Model.doClear();
		
		assertTrue("items did not clear",items.isEmpty());
		assertTrue("deathQueue did not clear",deathQueue.isEmpty());
		assertTrue("birthQueue did not clear",birthQueue.isEmpty());
	}

	/**
	 * Test method for {@link Model#doAddQueue()}.
	 */
	@Test
	public final void testDoAddQueue() {
		addQueue.add(bfrog01);
		addQueue.add(bfrog02);
		Model.setAddQueue(addQueue);
		assertTrue("items did not add to queue", Model.doAddQueue());
	}

	/**
	 * Test method for {@link Model#clearAndAdd()}.
	 */
	@Test
	public final void testClearAndAdd() {
		Model.addItem(bfrog01);
		Model.addItem(bfrog02);
		Model.addToBirthQueue(bfrog01);
		Model.addToBirthQueue(bfrog02);
		Model.addToDeathQueue(bfrog01);
		Model.addToDeathQueue(bfrog02);
		addQueue.add(bfrog01);
		addQueue.add(bfrog02);
		Model.setAddQueue(addQueue);
		Model.clearAndAdd();
		assertTrue("items did not clear",items.isEmpty());
		assertTrue("deathQueue did not clear",deathQueue.isEmpty());
		assertTrue("birthQueue did not clear",birthQueue.isEmpty());
	}

}
