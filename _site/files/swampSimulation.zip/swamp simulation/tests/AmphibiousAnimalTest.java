/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AmphibiousAnimalTest {
	static Model model;
	AmphibiousAnimal item1;
	AmphibiousAnimal item2;
	AmphibiousAnimal item3;
	AmphibiousAnimal item4;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		model = new Model(50,50);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		model = null;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		item1 = new AmphibiousAnimal(1, 13600, 8880, 3,5, "eating", 12); // in water 
		item2 = new AmphibiousAnimal(2, 11250, 1620, 3,5, "eating"); // on land
		item3 = new AmphibiousAnimal(3, 0, 0, 3,5, 12);
		item4 = new AmphibiousAnimal(4, 50, 50, 3, 5);
		new ArrayList<AmphibiousAnimal>();
		Model.addItem(item1);
		Model.addItem(item2);
		Model.addItem(item3);
		Model.addItem(item4);
	}
	
	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		item1 = null;
		item2 = null;
		item3 = null;
		item4 = null;
	}
	
	/**
	 * Test method for {@link AmphibiousAnimal#AmphibiousAnimal(int, int, int, int, int, java.lang.String, int)}.
	 */
	@Test
	public final void testAmphibiousAnimalConstruct1(){
		assertNotNull("AmphibiousAnimal constructor failed", item1);
	}
	
	/**
	 * Test method for {@link AmphibiousAnimal#AmphibiousAnimal(int, int, int, int, int, java.lang.String)}.
	 */
	@Test
	public final void testAmphibiousAnimalConstruct2(){
		assertNotNull("AmphibiousAnimal constructor failed", item2);
	}
	
	/**
	 * Test method for {@link AmphibiousAnimal#AmphibiousAnimal(int, int, int, int, int, int)}.
	 */
	@Test
	public final void testAmphibiousAnimalConstruct3(){
		assertNotNull("AmphibiousAnimal constructor failed", item3);
	}
	
	/**
	 * Test method for {@link AmphibiousAnimal#AmphibiousAnimal(int, int, int, int, int)}.
	 */
	@Test
	public final void testAmphibiousAnimalConstruct4(){
		assertNotNull("AmphibiousAnimal constructor failed", item4);
	}
	
	/**
	 * Test method for {@link AmphibiousAnimal#doSetAction()}.
	 */
	@Test
	public final void testDoSetAction(){
		item1.doSetAction();
		assertEquals("action did not change correctly", "swimming", item1.getAction());
		item2.doSetAction();
		assertEquals("action did not change correctly", "walking", item2.getAction());
	}
}