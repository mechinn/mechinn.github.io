/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class FlyingAnimalTest {
	static Model model;
	FlyingAnimal item1, item2, item3, item4;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		model = new Model(50,50);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		model = null;
	}

	@Before
	public void setUp() throws Exception {
		item1 = new FlyingAnimal();
		item2 = new FlyingAnimal(1,0,0,2,4);
		item3 = new FlyingAnimal(2,50,50,2,4,12);
		item4 = new FlyingAnimal(3,100,100,2,4,"flying",12);
		new ArrayList<FlyingAnimal>();
		Model.addItem(item1);
		Model.addItem(item2);
		Model.addItem(item3);
		Model.addItem(item4);
	}

	@After
	public void tearDown() throws Exception {
		item1 = null;
		item2 = null;
		item3 = null;
		item4 = null;
	}
	
	/**
	 * Test method for {@link FlyingAnimal#FlyingAnimal()}.
	 */
	@Test
	public final void testFlyingAnimalConstruct1(){
		assertNotNull("FlyingAnimal constructor failed", item1);
	}
	
	/**
	 * Test method for {@link FlyingAnimal#FlyingAnimal(int, int, int, int, int)}.
	 */
	@Test
	public final void testFlyingAnimalConstruct2(){
		assertNotNull("FlyingAnimal constructor failed", item2);
	}
	
	/**
	 * Test method for {@link FlyingAnimal#FlyingAnimal(int, int, int, int, int, int)}.
	 */
	@Test
	public final void testFlyingAnimalConstruct3(){
		assertNotNull("FlyingAnimal constructor failed", item3);
	}
	
	/**
	 * Test method for {@link FlyingAnimal#FlyingAnimal(int, int, int, int, int, String, int)}.
	 */
	@Test
	public final void testFlyingAnimalConstruct4(){
		assertNotNull("FlyingAnimal constructor failed", item4);
	}
}