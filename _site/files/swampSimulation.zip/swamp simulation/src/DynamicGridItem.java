/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.Point;
import java.awt.Polygon;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Random;
import java.util.Collection;

/**
 * Superclass of any variable item in simulation, basis of practically everything in model and is Serializable so it can save and load.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     Serializable
 */
public class DynamicGridItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1920908463620373207L;

	/** The number of frames in the image*/
	public int frames = 12;
	
	/** The generator - single instance of a random number generator */
	private static Random generator = new Random();
	
	/** The initalLifespan of a DynamicGridItem. */
	private static int initalLifespan = 10000;
	
	/** The max hunger of a DynamicGridItem. */
	private static int maxHunger = 2000;
	
	/** The max health of a DynamicGridItem. */
	private static int maxHealth = 2000;
	
	/** The eat factor - how much an eat decreases hunger, also doubles as attack strength. */
	private static int eatFactor = 20;
	
	/** The reproduction rate. */
	private static int reproRate = 5;
	
	/** The prey - if a DynamicGridItem is perusing another DynamicGridItem*/
	private DynamicGridItem prey;
	
	/** The action counter - used for determining delays and gauging interaction times . */
	private int actionCounter;
	
	/** The Allowed area - where a DynamicGridItem can make movements. */
	private Polygon AllowedArea;
	
	/** The chasing flag */
	private boolean chasing;
	
	/** The chasing food are we hunting something? */
	private boolean chasingFood;
	
	/** The chasing mate flag. */
	private boolean chasingMate;
	
	/** The center - DynamicGridItem's center, based on it's size. */
	private Point center;
	
	/** The pic index. - where we are in the animation frame count*/
	public int picIndex;
    
    /** The goal. - where we're headed */
    private Point goal;
	
	/** The speed - how fast we move. */
	private int speed;
    
    /** The loc - our location. */
    private Point loc;
    
    /** The move - our next move
     * 1 - North						
     * 2 - North East
     * 3 - South East
     * 4 - South
     * 5 - South West
     * 6 - North West
     * */
    private int move;
    
    /** The last move we made. */
    private int lastMove;
	
	/** The IDnumber */
	private int IDnum;
	
	/** The size - how much space we take up. */
	private int size;
	
	/** The age - how old we are. */
	private int age;
	
	/** The alive - we're not dead if true. */
	private boolean alive;
	
	/** The lifespan - how long we expect to live. */
	private int lifespan;
	
	/** The hunger - used for goal seeking, if this value is higher we're more likely to look for food.*/
	private int hunger;
	
	/** The hungry - Used in goalseeking. */
	private boolean hungry;
	
	/** The health - how alive are we. */
	private int health;
	
	/** The action - action used for determining which imageset to use. */
	public String action; // what are we currently doing? flying, walking, etc.  don't set if not needed! (i.e., a slug only moves in one way) used for graphics
	
	/** The default action - our default action. */
	public String defaultAction = ""; 
	
	/** The favorite foods - a list of subclasses we can eat. */
	public HashSet<String> favoriteFoods;
	
	/** The new action - label on the display. */
	public String newAction;
	
	/** The show label - so we can toggle labels. */
	private boolean showLabel = false;
	
	/** The reproducing - reproducing flag - How would you feel if someone interrupted?  */
	private boolean reproducing = false;
	
	/** The attacking flag- used in the labels. */
	private boolean attacking = false;
	
	/** The being attacked- used in the labels. */
	private boolean beingAttacked = false;
	
	/** The predator - who is attacking us. */
	private DynamicGridItem predator = null;
	
	/**
	 * Instantiates a new dynamic grid item. Sets Grid Item's starting values
	 *
	 * @param IDin the Grid Item's Unique ID number
	 * @param X the x location - location will be changed if outside the allowable range
	 * @param Y the y location
	 * @param getSpeed the get speed the item will move
	 * @param getSize the get size the animal will be (% of 256)
	 * @param getAction the get initial action 
	 * @param f the frames for the ImageLibrary to parse the image
	 */
	public DynamicGridItem(int IDin, int X, int Y, int getSpeed, int getSize, String getAction, int f){
    	center = new Point(X+getSize/2, Y+getSize/2);
		loc = new Point(X,Y);
		goal = new Point(-1,-1);

		actionCounter = -1;
		speed = getSpeed;
		size = getSize;
    	IDnum = IDin;
		picIndex = 0;
		alive = true;
		move = 0;
		lastMove = 0;
		age = 0;
		lifespan = getInitalLifespan();
		hunger = 0;
		health = maxHealth;
		chasing = chasingFood = chasingMate = false;
		action = getAction; // subclasses should set this as they move
		favoriteFoods = new HashSet<String>();
		frames = f;
		if(this.getClass().getSuperclass() != DynamicGridItem.class) { loadGraphics(); };
	}

	/**
	 * Load graphics from file. Makes call to the Image Library which will only load the files if they're not already loaded
	 */
	private void loadGraphics()
	{
		NewImageLibrary.addClassImage(this); // load graphics
	}
	
	/**
	 * Reads an object from a file - for serializable 
	 *
	 * @param in the inputStream
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws ClassNotFoundException the class not found exception
	 */
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		// we need to override the default readObject() method so that when a DynamicGridItem is loaded from file, the graphics are loaded
		in.defaultReadObject(); // perform default object read
		loadGraphics(); // load graphics
	}
	
	/**
	 * Getter for the initalLifespan.
	 *
	 * @return the initalLifespan
	 */
	public int getInitalLifespan(){return initalLifespan;}
	
	/**
	 * Getter for the typecode.
	 *
	 * @return the typecode
	 */
	String getTypecode(){return getClass().getName();}
	
	/**
	 * Gets the favorite foods.
	 *
	 * @return the favorite foods
	 */
	public Collection<String> getFavoriteFoods() { return favoriteFoods; }
	
	/**
	 * Gets the action counter.
	 *
	 * @return the action counter
	 */
	public int getActionCounter(){return actionCounter;}
	
	/**
	 * Sets the action counter.
	 *
	 * @param AC the new action counter
	 */
	public void setActionCounter(int AC){actionCounter = AC;}
	
	/**
	 * Decrease actionCounter.
	 */
	public void decreaseActionCounter(){actionCounter--;}
	
	/**
	 * Sets the allowedArea.
	 *
	 * @param in the new allowed area
	 */
	public void setAllowedArea(Polygon in){AllowedArea = in;}
	
	/**
	 * Gets the allowed area.
	 *
	 * @return the allowed area
	 */
	public Polygon getAllowedArea(){return AllowedArea;}
	
	/**
	 * Sets the chasing food.
	 */
	public void setChasingFood(){chasingFood = true;}
	
	/**
	 * Sets the chasing mate.
	 */
	public void setChasingMate(){chasingMate = true;}
	
	/**
	 * Gets the chasing mate.
	 *
	 * @return the chasing mate
	 */
	public boolean getChasingMate(){return chasingMate;}
	
	/**
	 * Reset chasing food flag.
	 */
	public void resetChasingFood(){chasingFood = false;}
	
	/**
	 * Reset chasing mate flag.
	 */
	public void resetChasingMate(){chasingMate = false;}
	
	/**
	 * Checks if is alive.
	 *
	 * @return true, if is alive
	 */
	public boolean isAlive(){return alive;}
	
	/**
	 * Gets the chasing flag.
	 *
	 * @return the chasing
	 */
	public boolean getChasing(){return chasing;}
	
	/**
	 * Gets the age.
	 *
	 * @return the age
	 */
	public int getAge(){return age;}
	
	/**
	 * Increment age.
	 */
	public void incrementAge(){age++;}
	
	/**
	 * Sets the age.
	 *
	 * @param inage the new age
	 */
	public void setAge(int inage){age=inage;}
	
	/**
	 * Gets the lifespan.
	 *
	 * @return the lifespan
	 */
	public int getLifespan(){return lifespan;}
	
	/**
	 * Gets the prey.
	 *
	 * @return the prey
	 */
	public DynamicGridItem getPrey(){return prey;}
	
	/**
	 * Sets the chasing flag.
	 *
	 * @param c the new chasing
	 */
	public void setChasing(boolean c){chasing = c;}
    
    /**
     * Gets the location.
     *
     * @return the loc
     */
    public Point getLoc(){return loc;}
    
    /**
     * Gets the center.
     *
     * @return the center
     */
    public Point getCenter(){return center;}
    
    /**
     * Gets the x coord.
     *
     * @return the x coord
     */
    public int getXCoord(){return (int)loc.getX();}
	
	/**
	 * Generate random number .
	 *
	 * @param range the range
	 * @return the int
	 */
	public static int genRand(int range){return generator.nextInt(range);}
    
    /**
     * Gets the y coord.
     *
     * @return the y coord
     */
    public int getYCoord(){return (int)loc.getY();}
    
    /**
     * Gets the frames.
     *
     * @return the frames
     */
    public int getFrames() {return frames;}
    
    /**
     * Gets the current pic index.
     *
     * @return the pic index
     */
    public int getPicIndex() {return picIndex;}
    
    /**
     * Gets the goal.
     *
     * @return the goal
     */
    public Point getGoal(){return goal;}
    
    /**
     * Gets the next move.
     *
     * @return the move
     */
    public int getMove() { return move; }
    
    /**
     * Gets the action.
     *
     * @return the action
     */
    public String getAction() { return action; }
    
    /**
     * Sets the action.
     *
     * @param a the new action
     */
    public void setAction(String a) { action = a; }
    
    /**
     * Gets the new action.
     *
     * @return the new action
     */
    public String getNewAction() { return newAction; }
    
    /**
     * Sets the new action.
     *
     * @param na the new new action
     */
    public void setNewAction(String na) { newAction = na; }
    
    /**
     * Gets the speed.
     *
     * @return the speed
     */
    public int getSpeed() {return speed; }
    
    /**
     * Gets the last move.
     *
     * @return the last move
     */
    public int getLastMove() { return lastMove; }  
    
    /**
     * Gets the size.
     *
     * @return the size
     */
    public int getSize() { return size; }
    
    /**
     * Gets the IDnum.
     *
     * @return the IDnum
     */
    public int getIDnum() { return IDnum; }
	
	/**
	 * Gets the health.
	 *
	 * @return the health
	 */
	public int getHealth(){return health;}
	
	/**
	 * Sets the health.
	 *
	 * @param h the new health
	 */
	public void setHealth(int h){health = h;}
	
	/**
	 * Gets the hunger.
	 *
	 * @return the hunger
	 */
	public int getHunger(){return hunger;}
	
	/**
	 * Gets the repro rate.
	 *
	 * @return the repro rate
	 */
	public int getreproRate(){ return reproRate;}
	
	/**
	 * Gets the default action.
	 *
	 * @return the default action
	 */
	public String getDefaultAction() { return defaultAction; }
	
	/**
	 * Gets the show label.
	 *
	 * @return the show label
	 */
	public boolean getShowLabel() { return showLabel; }
	
	/**
	 * Sets the show label.
	 *
	 * @param b the new show label
	 */
	public void setShowLabel(boolean b) { showLabel = b; }
	
	/**
	 * Sets the reproducing flag.
	 *
	 * @param b the new reproducing
	 */
	public void setReproducing(boolean b) { reproducing = b; }
	
	/**
	 * Gets the reproducing flag.
	 *
	 * @return the reproducing
	 */
	public boolean getReproducing() { return reproducing; }
	
	/**
	 * Sets the attacking flag.
	 *
	 * @param b the new attacking
	 */
	public void setAttacking(boolean b) { attacking = b; }
	
	/**
	 * Gets the attacking flag.
	 *
	 * @return the attacking
	 */
	public boolean getAttacking() { return attacking; }
	
	/**
	 * Sets the being attacked flag.
	 *
	 * @param b the new being attacked
	 */
	public void setBeingAttacked(boolean b) { beingAttacked = b; }
	
	/**
	 * Gets the being attacked flag.
	 *
	 * @return the being attacked
	 */
	public boolean getBeingAttacked() { return beingAttacked; }
	
	/**
	 * Gets the predator DGI.
	 *
	 * @return the predator
	 */
	public DynamicGridItem getPredator() { return predator; }
	
	/**
	 * Sets the predator.
	 *
	 * @param d the new predator
	 */
	public void setPredator(DynamicGridItem d) { predator = d; }
	
	/**
	 * Sets the frames.
	 *
	 * @param f the new frames
	 */
	public void setFrames(int f) { frames = f; }
	
	/**
	 * Reset hungry flag.
	 */
	public void resetHungry(){hungry = false;}
	
	/**
	 * Sets the hungry flag.
	 */
	public void setHungry(){hungry = true;}
	
	/**
	 * Gets the hungry flag.
	 *
	 * @return the hungry
	 */
	public boolean getHungry(){return hungry;}
	
	/**
	 * Gets the max hunger.
	 *
	 * @return the max hunger
	 */
	public int getmaxHunger(){return maxHunger;}
	
    /**
     * Sets the speed - we can never have a < 0 speed.
     *
     * @param getSpeed the new speed
     */
    public void setSpeed(int getSpeed) {
    	if(getSpeed>0) {
    		speed = getSpeed;
    	} else {
    		speed = 1;
    	}
    }
    
    /**
     * Sets the move and keeps track of the last move .
     *
     * @param m the new move
     */
    public void setMove(int m) {
		if(move > 0) lastMove = move;
    	move = m;
    }

	/**
	 * Increase hunger - im hungry.
	 */
	public void increaseHunger(){
		if(hunger < maxHunger){
			hunger++;
		}
		else{
			health--;	// if we're starving we should start dying a bit on the inside
		}
	}

	/**
	 * Kill DGI - add to death Queue to clean up the dead.
	 */
	public void kill() {
			System.out.println(this + " died");
			age = 0;
			move = -1; // so the image library knows to return the dead image
			alive = false;
			Model.deathQueue.add(this);
	}

	/**
	 * Gets the closest DynamicGridItem of the typecode specified in the string. returns null if there aren't any
	 *
	 * @param t the type - typecode of the target subclass
	 * @return the closest
	 */
	private DynamicGridItem getClosest(String t) {
		double cDist = -1;
		DynamicGridItem cAnimal = null;
		for(DynamicGridItem di : Model.getItems()){
			if(di.getTypecode() == t){
				if((cDist == -1 || distance(this.getLoc(), di.getLoc()) < cDist)&&(di!=this)){
					cAnimal = di;
					cDist = distance(this.getLoc(), di.getLoc());
				}
			}
		}
		return cAnimal;
	}

	/**
	 * Find the closest mate. If they're not busy with someone else tell them you're interested
	 *
	 * @return true, if successful
	 */
	public boolean findMate(){
		DynamicGridItem mate = getClosest(this.getTypecode());
		if(mate == null||mate.getChasingMate()||mate.isCarryingChild())
			return false;

		this.chase(mate);
		this.setChasingMate();
		this.resetChasingFood();
		mate.setChasingMate();
		mate.resetChasingFood();
		mate.chase(this);
		return true;
	}

	/**
	 * Find closest prey. If it's too far away let it go. Otherwise go after it
	 *
	 * @return true, if successful
	 */
	public boolean findPrey(){
		double closestDist = -1;
		double currentDist;
		DynamicGridItem closest = null;

		// find the closest favorite food
		for(String foodName : this.favoriteFoods){
			DynamicGridItem food = getClosest(foodName);
			if(food !=null){
				currentDist = distance(this.getLoc(),food.getLoc());
				if(closestDist == -1 || currentDist < closestDist){
					closest = food;
					closestDist = currentDist;
				}
			}
		}
		//an animal won't hunt down food that's too far away
		if(closestDist>5000){
			closest = null;	
		}	
		if(closest != null){
			this.chase(closest);
			this.setChasingFood();
			chasingMate = false;
			newAction = " hunting " + closest;
			return true;
		}
		else{
			return false;
		}
	}
	
    /**
     * Decide where it's next goal location is.
     * If it's hungry try and find food
     * If it's not hungry see if it should be
     *
     */
	public void changeGoal(){
		int x = 0, y = 0;

//		System.out.println(this + " chasing:" + chasing + " hungry " + hungry);
		
		//chance of wanting to find mate
		if(generator.nextInt(100)<this.getreproRate()){
			if(findMate()){
				nextMove();
				this.setActionCounter(-1);
				return;
			}				
		}
		// if we're hungry look for food
		if(hungry){
			if(findPrey()){
				nextMove();
				this.setActionCounter(-1);
				return;
			}		
		}
		else if(generator.nextInt(maxHunger)<hunger){
			hungry = true;
			newAction = " is hungry";
			return;
		}
		// otherwise we wander
		while(!this.getAllowedArea().contains(x,y)){
			x = generator.nextInt(15000);
			y = generator.nextInt(15000);
		}
		this.setGoal(x,y);
		updateLabelText();
		nextMove();
		this.setActionCounter(-1);
	}

	/**
	 * Checks if is carrying child - only frogs carry children .
	 *
	 * @return true, if is carrying child
	 */
	public boolean isCarryingChild(){return false;}

	/**
	 * Update label text.
	 */
	public void updateLabelText(){
		String hw="", aw="";
		if(getAction() != "") aw = "is " + getAction(); else aw = "is " + getDefaultAction(); // most primitive
		if(hungry) hw = " and hungry";
		if(isCarryingChild()) aw = "is carrying child";
		if(chasingMate) { aw = "wants to mate with " + prey; hw = ""; }
		if(getReproducing()) { aw = "is mating with " + prey; hw = ""; }
		if(getAttacking()) { if(prey.isAlive()) aw = "is attacking "; else aw = "is eating ";  hw = prey.toString(); }
		if(getBeingAttacked()) { aw = "is being attacked by " + getPredator(); hw = ""; }
		if(!alive) { aw = "is dead"; hw=""; } // most important (if we're dead, nothing else matters)
		newAction = " " + aw + hw;
	}
	
	// find out if we're just aimlessly wandering...
	public boolean isWandering()
	{
		return !getAttacking() && !getBeingAttacked() && !getReproducing() && !chasingMate && !isCarryingChild();
	}
	
    /**
     * Calculate distance between two items.
     *
     * @param	loc1    Point where the GridItem currently is.
     * @param	x2	Where the GridItem is going on the X axis.
     * @param	y2	Where the GridItem is going on the Y axis.
     *
     * @return	the mathematical distance formula.
     */
    public double distance(Point loc1, double x2, double y2){
		double x1 = loc1.getX(); //goal
		double y1 = loc1.getY(); //goal
		return (Math.sqrt(Math.pow(x2-x1,2.0) + Math.pow(y2-y1,2.0)));
    }
    
    /**
     * Distance - same as above.
     *
     * @param loc1 the loc1
     * @param loc2 the loc2
     * @return the double
     */
    public double distance(Point loc1, Point loc2){
		double x2 = loc2.getX();
		double y2 = loc2.getY();
		return distance(loc1, x2, y2);
    }
    
    /**
     * Uses the distance method to determine where an object should go next. 
     * Goes through each possible move and finds the shortest move 
     *
     */
    public void nextMove(){		
		int x = getCenter().x;
		int y = getCenter().y;
		int newMove = 0;
		double dist	= 500000;
		
		// if we're chasing, we should first update our goal
		if(chasing){
			chase(prey);
		}
		
		//Go through each possible move and return the one with the smallest distance
		if(picIndex%frames==0){ //need to wait until current animation is finished all animations have 12 frames
			//north
			if(isValidMove(1)&&(dist > distance(goal,x,y-8*12))){
				newMove = 1; 
				dist = distance(goal,x,y-8*12);
			}
			else if (!this.isOutsideTrees(x,y-8*12)){
				newMove = 5; // go south west
			}
			
			//north east
			if(isValidMove(2)&&(dist > distance(goal,x+7*12,y-4*12))){
				newMove = 2;
				dist = distance(goal,x+7*12,y-4*12);
			}
			else if (!this.isOutsideTrees(x+7*12,y-4*12)){
				newMove = 6; // go north west
			}
			
			//south east
			if(isValidMove(3)&&(dist > distance(goal,x+7*12,y+4*12))){
				newMove = 3; 
				dist = distance(goal,x+7*12,y+4*12);
			}
			else if (!this.isOutsideTrees(x+7*12,y+4*12)){
				newMove = 2; // go north east
			}
			
			//south
			if(isValidMove(4)&&(dist > distance(goal,x,y+8*12))){
				newMove = 4; 
				dist = distance(goal,x,y+8*12);
			}
			else if (!this.isOutsideTrees(x,y+8*12)){
				newMove = 5; // go south west
			}
			
			//south west
			if(isValidMove(5)&&(dist > distance(goal,x-7*12,y+4*12))){
				newMove = 5; 
				dist = distance(goal,x-7*12,y+4*12);
			}
			
			else if (!this.isOutsideTrees(x-7*12,y+4*12)){
				newMove = 3; // go south east
			}
			
			//north west
			if(isValidMove(6)&&(dist>distance(goal,x-7*12,y-4*12))){
				newMove = 6; 
				dist = distance(goal,x-7*12,y-4*12);
			}
			else if (!this.isOutsideTrees(x-7*12,y-4*12)){
				newMove = 2; // go north east
			}
			setMove(newMove);
		}
    }

    //Check to make sure the next move is valid
	/**
     * Checks if is valid move.
     * Makes sure the animals don't turn too quickly
     * Also checks that where it's moving is a valid location
     *
     * @param checkMove the check move
     * @return true, if is valid move
     */
    public boolean isValidMove(int checkMove){
		boolean turn = false;
		switch(move){
			case 0: return true;
			case 1: if((checkMove==6||checkMove==2)){turn = true;} break;
			case 2: if((checkMove==1||checkMove==3)){turn = true;} break;
			case 3: if((checkMove==2||checkMove==4)){turn = true;} break;
			case 4: if((checkMove==3||checkMove==5)){turn = true;} break;
			case 5: if((checkMove==4||checkMove==6)){turn = true;} break;
			case 6: if((checkMove==5||checkMove==1)){turn = true;} break;
		}
		if(turn){
			int x = this.getLoc().x;
			int y = this.getLoc().y;

			switch(checkMove){
				case 0:	return true;														// standing still
				case 1: if((this.getAllowedArea().contains(x,y-8*frames)) 
						&& this.isOutsideTrees(x,y-8*frames)){return true;}	break;			// north
				case 2: if((this.getAllowedArea().contains(x+7*frames,y-4*frames))
						&& this.isOutsideTrees(x+7*frames,y-4*frames)){return true;} break;	// north east
				case 3: if((this.getAllowedArea().contains(x+7*frames,y+4*frames))
						&& this.isOutsideTrees(x+7*frames,y+4*frames)){return true;} break;	// south east
				case 4: if((this.getAllowedArea().contains(x,y+8*frames))
						&& this.isOutsideTrees(x,y+8*frames)){return true;} break;			// south
				case 5: if((this.getAllowedArea().contains(x-7*frames,y+4*frames))
						&& this.isOutsideTrees(x-7*frames,y+4*frames)){return true;} break;	// south west
				case 6: if((this.getAllowedArea().contains(x-7*frames,y-4*frames))
						&& this.isOutsideTrees(x-7*frames,y-4*frames)){return true;} break;	// north west
			}
		}
		return false;
	}

	/**
	 * Checks if is outside trees. - DGI can't be inside of trees - thats silly
	 *
	 * @param x the x
	 * @param y the y
	 * @return true, if is outside trees
	 */
	public boolean isOutsideTrees(int x, int y){
		for(Polygon p : Model.getTreeList()){
			if(p.contains(x,y)){
				//System.out.println(this + " ran into a tree!");
				return false;
			}
		}
		return true;
	}
	
    /**
     * Sets the goal.
     *
     * @param X the x
     * @param Y the y
     */
    public void setGoal(int X, int Y){goal.setLocation(X,Y);}
    
    /**
     * Sets the loc. updates center, too
     *
     * @param X the x
     * @param Y the y
     */
    public void setLoc(int X, int Y){
		loc.setLocation(X,Y);
		center.setLocation(X+size/2,Y+size/2);
	}

    /**
     * Move item - changes an items location based on it's specified move.
     */
    public void moveItem(){
		int nx = getXCoord();
		int ny = getYCoord();

		switch(move){
			case 0:						break;	//Does not move
			case 1: ny -= 8;			break;	//North
			case 2: ny -= 4; nx += 7;	break;	//Northeast
			case 3: ny += 4; nx += 7;	break;	//Southeast
			case 4: ny += 8; 			break;	//South
			case 5: ny += 4; nx -= 7;	break;	//Southwest
			case 6: ny -= 4; nx -= 7;	break;	//Northwest
		}
		//Set the item's new location:
		setLoc(nx,ny);
		doSetAction();
		updateLabelText();
    }

    /**
     * Do set action - up to animal class specific implementation.
     */
    public void doSetAction(){} // up to animal class specific implementation
    
	/**
	 * Goal reached - check to see if we've reached our goal.
	 *
	 * @return true, if successful
	 */
	public boolean goalReached(){
		//NOTE: set to 200px for now, but for larger animals this may not be enough.
		//May need to implement so that it's specific to animal size...
		if(chasing)
			return distance(goal,getCenter().x,getCenter().y)<12*12*4;		
		else
			return distance(goal,getCenter().x,getCenter().y)<12*12*2;
	}

	/**
	 * Reproduce - implementation specific. Just prints a nice error and no babies are made
	 */
	public void reproduce(){
		System.out.println(this.getTypecode() + " Missing reproduction implementation");
	}
	
	/**
	 * Start goal event - a bunch of logic to determine what to do when we reach our goal.
	 * In short:
	 * 		If we're hunting we attack
	 * 		If we're persuing a mate we mate
	 * 		Otherwise we just kinda relax for a sec
	 * 		setting the actioncounter specifies how long the action lasts 
	 * 		ie. eating takes a long time (or can) mating is quick (sadly)
	 */
	public void startGoalEvent(){
		if(chasing){
			if(chasingFood){
				if(prey.isAlive()){
					setAttacking(true);
					prey.setBeingAttacked(true);
					prey.setPredator(this);
					this.attack(prey);
					chase(prey);
					actionCounter = -1;
				}
				else{
					System.out.println(this + " before health = " +health + " hunger " + hunger);
					chasing = false;
					actionCounter = 1350;
				}
			}
			else{
				chasing = false; // if we were chasing and goal is reached, we're no longer chasing
				actionCounter = 135;
				if(chasingMate) {
					setReproducing(true);
					prey.setReproducing(true);
				}
			}
		}
		else
			actionCounter = 0;	
		setMove(0);
		updateLabelText();
	}

	/**
	 * Intermediate goal event.
	 * 		Mostly just used for eating
	 * 		Ideally used for actions that require incremental-ism 
	 * 		Ex: eating - you only eat until you're full 
	 */
	public void intermediateGoalEvent(){
		if(chasingFood){
			if(Model.deathQueue.contains(this.prey)){
				if(actionCounter%5==0){
					if(hunger>0){
						hunger-=eatFactor;
						if(health<maxHealth)
							health+=eatFactor;
						else
							lifespan++;
					}
					else
						actionCounter = 0;	
				}
			}
			else{
				actionCounter = 0;	
			}
		}
	}

	/**
	 * End goal event.
	 * resolve anything that happened during an action and get things ready to continue life
	 * babies are born here (at the end of mating)
	 * reset all flags when actions are over
	 */
	public void endGoalEvent(){
		if(chasingMate){
			reproduce();
			chasingMate = false;
			chasingFood = false;
			setReproducing(false);
			prey.setReproducing(false);
			prey.resetChasingMate();
			prey.updateLabelText();
		}
		if(chasingFood){
			System.out.println(this + " after health = " +health + " hunger " + hunger);
			setAttacking(false);
			prey.setBeingAttacked(false);
			prey.updateLabelText();
			hunger = 0;
			chasingMate = false;
			chasingFood = false;
			hungry = false;
		}
//		updateLabelText();
	}

	/**
	 * Move action.
	 * This happens every move
	 * DGI get older, hungrier and generally more cranky
	 * If they get too old they die 
	 */
	public void moveAction(){
		picIndex++;
		increaseHunger();
		updateLabelText();
		age++;
		if(age>lifespan||health<0){
			this.kill();
			updateLabelText();
		}
		if(hungry&&!chasingFood){
			if(findPrey()){
				nextMove();
				this.setActionCounter(-1);
			}
		}
	}

	/**
	 * Chase - a dynamic goal seeking tool.
	 *
	 * @param newPrey the new prey
	 */
	public void chase(DynamicGridItem newPrey){
		prey = newPrey;
		chasing = true;
		setGoal(prey.getXCoord(), prey.getYCoord());
	}
	
	/**
	 * Attack - Attacking a victim. Decrease their health and force them to slow down by giving them an action counter
	 *
	 * @param victim the victim
	 */
	public void attack(DynamicGridItem victim){
		victim.setHealth(victim.getHealth()-75);
		if(victim.getHealth()<=0)
			victim.kill();
		victim.setActionCounter(1);	// If you're being attacked you should get delayed
		updateLabelText();
	}

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString(){
		return (getTypecode() + IDnum);
    }
}
