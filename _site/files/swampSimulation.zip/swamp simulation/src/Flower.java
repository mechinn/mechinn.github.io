/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Subclass of LandAnimal which is immobile due to it being a flower.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     LandAnimal
 */
public class Flower extends LandAnimal {
	
/**
	 * 
	 */
	private static final long serialVersionUID = -8401602236292792303L;
	
	/** The speed. */
	private static int speed = 10;
	
	/** The scale. */
	private static int scale = 20;
	
	/** The counter. */
	private static int counter = 0;
	
	/** The reproduction rate. */
	private static int reproRate = 1;

	/**
	 * Instantiates a new flower.
	 *
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 */
	public Flower(int X, int Y){
		super(counter++,X,Y,speed,scale);
	}

	/* (non-Javadoc)
	 * @see DynamicGridItem#moveItem()
	 */
	public void moveItem(){
		if(DynamicGridItem.genRand(7500)<reproRate){
			int x = DynamicGridItem.genRand(3)*256-256;
			int y = DynamicGridItem.genRand(3)*256-256;
			Model.addToBirthQueue(new Flower(this.getXCoord()+x,this.getYCoord()+y));
		}

		newAction = "";
	}

	/* (non-Javadoc)
	 * @see DynamicGridItem#getreproRate()
	 */
	public int getreproRate(){ return reproRate;}
	
	/**
	 * Sets the reproduction rate.
	 *
	 * @param reproIn the new reproduction rate
	 */
	public static void setreproRate(int reproIn){reproRate = reproIn;}

	/* (non-Javadoc)
	 * @see DynamicGridItem#changeGoal()
	 */
	public void changeGoal(){}
	
	/* (non-Javadoc)
	 * @see DynamicGridItem#isOutsideTrees(int, int)
	 */
	public boolean isOutsideTrees(int x, int y){return false;}

	/* (non-Javadoc)
	 * @see DynamicGridItem#moveAction()
	 */
	public void moveAction(){
		incrementAge();
		if(getAge()>getLifespan()){
			this.kill();
		}
	}
}
