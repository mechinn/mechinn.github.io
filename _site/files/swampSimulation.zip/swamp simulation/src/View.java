/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.reflect.InvocationTargetException;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * View, holds simulation graphics and user interface.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     ChangeListener
 * @see     ActionListener
 * @see     KeyListener
 */
public class View implements ChangeListener, ActionListener, KeyListener, ComponentListener {
	
	/** The window. */
	private static JFrame window;
	
	/** The viewport. */
	private static Viewport viewport;
	
	/** The swamp. */
	private static SwampView swamp;
	
	/** The delay. */
	private JSlider delay;
	
	/** The play button. */
	private JButton playButton;
	
	/** The bar. */
	private JToolBar bar;
	
	/** The save button. */
	private JButton saveButton;
	
	/** The load button. */
	private JButton loadButton;
	
	/** The labels button. */
	private JButton labelsButton;
	
	/** The menu button. */
	private JButton menuButton;
	
	/** The minimap. */
	private MiniMap minimap;
	
	/** The controls. */
	private JPanel controls;
	
	/** The buttons. */
	private JPanel buttons;
	
	/** The scales. */
	private JPanel scales;
	
	/** The delay scales. */
	private JPanel delayScales;
	
	/** The reproduction frame. (birth control box) */
	private static JFrame reproFrame;
	
	/** The reproduction button. */
	private JButton reproButton;
	
	/** The main menu dialog. */
	private JDialog mmDialog;
	
	/** The reproduction sliders. */
	private JPanel reproSliders;
	
	private JPanel viewScaleScales;
	
	private static JSlider viewScale;

	private JLabel[] animalRepoLabels;

	private JSlider[] animalRepoSliders;
	private JButton[] animalRepoButtons;
	private JButton[] animalDeathButtons;
	
	private JPanel[] animalLSPairs;
	
	@SuppressWarnings("rawtypes")
	private Class[] animals;
	
	private static double maxscale = 5;
	
	/** The show labels. */
	private static boolean showLabels = true;
	GraphicsEnvironment env;
	
	/**
	 * Instantiates a new view.
	 */
	public View() {
		window = new JFrame("CISC 275 Group 2 - Simulation");
		JFrame.setDefaultLookAndFeelDecorated(true);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//sets it within the max visible boundaries or 1000 whichever is smaller
		env = GraphicsEnvironment.getLocalGraphicsEnvironment();
		window.setMaximizedBounds(env.getMaximumWindowBounds());
		int width = Math.min(env.getMaximumWindowBounds().width, 1000);
		int height = Math.min(env.getMaximumWindowBounds().height, 1000);
		window.setSize(width,height);

		window.setLocation(0, 0);

		window.setLayout(new BorderLayout());
		swamp = new SwampView();
		viewport = new Viewport(swamp);
		bar = new JToolBar();
		controls = new JPanel();
		controls.setLayout(new BorderLayout());
		buttons = new JPanel();
		buttons.setLayout(new GridLayout(1,3));
		
		menuButton = new JButton("Menu");
		menuButton.addActionListener(this);
		menuButton.addKeyListener(this);
		buttons.add(menuButton);
		
		//Create a button which allows user to pause image movement:
		playButton = new JButton("Pause");
		playButton.addActionListener(this);
		playButton.addKeyListener(this);
		buttons.add(playButton);
		
		labelsButton = new JButton("Hide Labels");
		labelsButton.addActionListener(this);
		labelsButton.addKeyListener(this);
		buttons.add(labelsButton);
		
		reproButton = new JButton("Birth Control");
		reproButton.addActionListener(this);
		reproButton.addKeyListener(this);
		buttons.add(reproButton);
		
		controls.add("North",buttons);
		
		scales = new JPanel();
		scales.setLayout(new GridLayout(2,1));
		
		delayScales = new JPanel();
		delayScales.setLayout(new BorderLayout());
		
		//Set labels for scale and delay sliders:
		JLabel delayLabel = new JLabel("Delay: ");
		delayScales.add("West",delayLabel);
		
		//Create a slider in which the user can change the speed of the image movement:
		delay = new JSlider(0,100,5);
		delay.setMajorTickSpacing(5);
		delay.setMinorTickSpacing(1);
		delay.setPaintTicks(true);
		delay.setPaintLabels(true);
		delay.addChangeListener(this);
		delay.addKeyListener(this);
		delayScales.add("Center",delay);
		
		scales.add(delayScales);
		
		viewScaleScales = new JPanel();
		viewScaleScales.setLayout(new BorderLayout());
		
		JLabel viewScaleLabel = new JLabel("Scale: ");
		viewScaleScales.add("West",viewScaleLabel);
		
		//Create a slider in which the user can change the speed of the image movement:
		viewScale = new JSlider(0,100,0);
		viewScale.setMajorTickSpacing(5);
		viewScale.setMinorTickSpacing(1);
		viewScale.setPaintTicks(true);
		viewScale.setPaintLabels(true);
		viewScale.addChangeListener(this);
		viewScale.addKeyListener(this);
		viewScaleScales.add("Center",viewScale);
		
		scales.add(viewScaleScales);
		
		// generate stuff for reproduction box
		animals = Setup.getAnimals(); // get list of animals from setup class, excluding the tadpole which can't reproduce
		animalRepoLabels = new JLabel[animals.length];
		animalRepoSliders = new JSlider[animals.length];
		animalRepoButtons = new JButton[animals.length];
		animalDeathButtons = new JButton[animals.length];
		animalLSPairs = new JPanel[animals.length];
		for(int i = 0; i < animals.length; i++)
		{
			animalLSPairs[i] = new JPanel(new GridLayout(1,3));
			animalRepoLabels[i] = new JLabel(animals[i].getName()+" ",JLabel.RIGHT);
			animalRepoButtons[i] = new JButton("Spawn");
			animalDeathButtons[i] = new JButton("Kill");
			animalRepoButtons[i].addActionListener(this);
			animalDeathButtons[i].addActionListener(this);
			animalRepoSliders[i] = new JSlider(0,50,5);
			animalRepoSliders[i].setMajorTickSpacing(10);
			animalRepoSliders[i].setMinorTickSpacing(5);
			animalRepoSliders[i].setPaintTicks(true);
			animalRepoSliders[i].setPaintLabels(true);
			animalRepoSliders[i].setSnapToTicks(true);
			animalRepoSliders[i].addChangeListener(this);
		}

		controls.add("Center",scales);
		
		bar.add(controls);
		
		minimap = new MiniMap(viewport);
		bar.add(minimap);
		
		window.add("Center",viewport);

		window.add("South",bar);
		
		window.addKeyListener(this);
		window.addComponentListener(this);
		window.setVisible(true);
	}

	/**
	 * Repaint the window.
	 */
	public static void repaint() {
		window.repaint();
	}
	
	/**
	 * Hide the window.
	 */
	public void hide()
	{
		window.setVisible(false);
	}
	
	/**
	 * Show the window.
	 */
	public void show()
	{
		window.setVisible(true);
	}
	
	/**
	 * Open main menu.
	 */
	private void openMainMenu()
	{
		MainMenuListener l = new MainMenuListener();
		int width = 200;
		int height = 300;
		
		mmDialog = new JDialog(window,false);
		JPanel panel = new JPanel();
		String[] buttonTxt = {"Swamp Statistics", "New Swamp", "Load Swamp", "Save Swamp", "Exit", "Close Menu (ESC)"};
		JButton[] buttons = new JButton[buttonTxt.length];
		panel.setLayout(new GridLayout(buttonTxt.length,1));
		for(int i = 0; i < buttonTxt.length; i++) {
			buttons[i] = new JButton(buttonTxt[i]);
			buttons[i].addActionListener(l);
			buttons[i].addKeyListener(l);
			panel.add(buttons[i]);
		}
		mmDialog.add(panel);
		mmDialog.setUndecorated(true);
		mmDialog.setTitle("Main Menu");
		mmDialog.setSize(new Dimension(width,height));
		mmDialog.setLocation(window.getX()+window.getWidth()/2-width/2, window.getY()+window.getHeight()/2-height/2);
		panel.addKeyListener(l);
		mmDialog.addKeyListener(l);
		mmDialog.setVisible(true);
	}
	
	/**
	 * The listener interface for receiving mainMenu events.
	 * The class that is interested in processing a mainMenu
	 * event implements this interface, and the object created
	 * with that class is registered with a component using the
	 * component's <code>addMainMenuListener<code> method. When
	 * the mainMenu event occurs, that object's appropriate
	 * method is invoked.
	 *
	 * @see MainMenuEvent
	 */
	class MainMenuListener implements ChangeListener, ActionListener, KeyListener
	{	
		
		/* (non-Javadoc)
		 * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
		 */
		@Override
		public void stateChanged(ChangeEvent arg0) {
			
		}

		/* (non-Javadoc)
		 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
		 */
		@Override
		public void actionPerformed(ActionEvent e) {
			String btext = ((JButton)(e.getSource())).getText();
			
			if(btext.equals("Swamp Statistics")) {
				SwampStatistics.showStatsWindow();
				SwampStatistics.update();
			} else if(btext.equals("New Swamp")) {
				window.setVisible(false);
				Controller.exit();
			} else if(btext.equals("Load Swamp")) {
				Setup.swampFromFile(window);
			} else if(btext.equals("Save Swamp")) {
				Setup.swampToFile(window);
			} else if(btext.equals("Exit")) {
				System.exit(0);
			} else if(btext.equals("Close Menu (ESC)")) {
				mmDialog.setVisible(false);
			}
			//mmDialog.setVisible(false);
		}

		/* (non-Javadoc)
		 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
		 */
		@Override
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode() == 27)
			{ // escape pressed
				mmDialog.setVisible(false);
			}
		}

		/* (non-Javadoc)
		 * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
		 */
		@Override
		public void keyReleased(KeyEvent e) {}

		/* (non-Javadoc)
		 * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
		 */
		@Override
		public void keyTyped(KeyEvent e) {}
		
	}
	
	/**
	 * Gets the show labels.
	 *
	 * @return the show labels
	 */
	public static boolean getShowLabels() { return showLabels; }
	
	/**
	 * Sets the show labels.
	 *
	 * @param b the new show labels
	 */
	public static void setShowLabels(boolean b) { showLabels = b; }
	
	private int getRepoSlider(JSlider src)
	{
		for(int i = 0; i < animals.length; i++) 
		{
			if(animalRepoSliders[i] == src) return i;
		}
		return -1;
	}
	
	private int getRepoButton(JButton src)
	{
		for(int i = 0; i < animals.length; i++) 
		{
			if(animalRepoButtons[i] == src || animalDeathButtons[i] == src) return i;
		}
		return -1;
	}
	
	@SuppressWarnings("unchecked")
	private void repoSliderChanged(int idx, JSlider slider)
	{
		// animals[idx] is the class we want
		try {
			try {
				animals[idx].getDeclaredMethod("setreproRate",int.class).invoke(this,slider.getValue());
			} catch (IllegalArgumentException e) {
			} catch (IllegalAccessException e) {
			} catch (InvocationTargetException e) {
			}
		} catch (SecurityException e) {
		} catch (NoSuchMethodException e) {
			System.out.println("A " + animals[idx].getName().toLowerCase() + " can't enjoy the intimate pleasure of another " + animals[idx].getName() + " :(");
		}
	}
	
	/**
	 * Called when the "Spawn" or "Kill" buttons are clicked.  This method spawns or kills an animal.
	 * 
	 */
	@SuppressWarnings("unchecked")
	private void repoButtonClicked(int idx, JButton button)
	{
		if(button.getText().equals("Spawn")) {
			System.out.println("Spawning a new " + animals[idx].getName() + "...");
		} else if(button.getText().equals("Kill")) {
			System.out.print("Killing a random " + animals[idx].getName() + "...");
		}
		try {
			try {
				if(button.getText().equals("Spawn")) {
					Model.addToBirthQueue((DynamicGridItem)animals[idx].getConstructor(int.class, int.class).newInstance(0,0));
				} else if(button.getText().equals("Kill")) {
					DynamicGridItem itk = Model.getRandomItem(animals[idx].getName());
					if(itk == null) System.out.println(" can't find one!"); else {
					itk.kill(); }
				}
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			}
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 *  Generate and display the "birth control" box.  this should only be run once.  Once the box is already
	 *  created, it can be toggled on and off by doing reproFrame.setVisible(true/false).
	 */
	private void openRepoBox()
	{
		int width = Math.min(env.getMaximumWindowBounds().width, 1000);
		int height = Math.min(env.getMaximumWindowBounds().height, 600);
		
		reproFrame = new JFrame("CISC 275 Group 2 - Birth Control");
		reproFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		reproFrame.setLocation(0, 0);
		
		reproFrame.setLayout(new BorderLayout());
		
		reproSliders = new JPanel();
		reproSliders.setLayout(new GridLayout((int)Math.ceil((double)animals.length/2),2*2));
//		reproSliders.setLayout(new GridBagLayout());
		//Set labels for scale and delay sliders:
		JLabel frameLabel = new JLabel("Set reproduction rate, spawn, and kill animals: ");
		reproFrame.add("North",frameLabel);
		
		String[] species = new String[animals.length];
		for(int i = 0; i < animals.length; i++) species[i] = animals[i].getName();
		JPanel aempanel = new JPanel(new GridLayout(1,2));
		JPanel aepanel = new JPanel();
		JPanel nukepanel = new JPanel();
		JComboBox aelist = new JComboBox(species);
		JButton aebutton = new JButton("Make Extinct");
		aebutton.setBackground(Color.orange);
		JButton nukebutton = new JButton("Nuke Swamp");
		nukebutton.setBackground(Color.red);
		nukebutton.setForeground(Color.white);
		
		RepoListener l = new RepoListener(aelist, aebutton, nukebutton);
		aebutton.addActionListener(l);
		nukebutton.addActionListener(l);
		
		aepanel.add(aelist);
		aepanel.add(aebutton);
		nukepanel.add(nukebutton);
		aempanel.add(aepanel);
		aempanel.add(nukepanel);
	
		
		for(int i = 0; i < animals.length; i++)
		{
			animalLSPairs[i].add(animalRepoLabels[i]);
			animalLSPairs[i].add(animalRepoButtons[i]);
			animalLSPairs[i].add(animalDeathButtons[i]);
			reproSliders.add(animalLSPairs[i]);
			reproSliders.add(animalRepoSliders[i]);
		}
		reproFrame.add("South",aempanel);
		reproFrame.add("Center",reproSliders);
		reproFrame.setSize(width,height);
		reproFrame.setVisible(true);
		
	}
	
	static public void closeRepoBox()
	{
		if(reproFrame != null) reproFrame.setVisible(false);
	}
	
	/**
	 * Simple class whose only function is to listen to events created by the "birth control" box. 
	 * I added the events in here instead of in the normal View action listener to keep things a little 
	 * more organized.
	 */
	class RepoListener implements ActionListener
	{
		private JComboBox box;
		private JButton ae, ex;
		public RepoListener(JComboBox boxin, JButton aein, JButton exin)
		{
			box = boxin;
			ae = aein;
			ex = exin;
		}
		
		public void actionPerformed(ActionEvent e) {
			JButton source;
			if(e.getSource() instanceof JButton) source = (JButton)e.getSource(); else source = null;
			
			if(source == ae) {
				System.out.println("Making " + box.getSelectedItem().toString() + " extinct!");
				Model.makeExtinct(box.getSelectedItem().toString());
			} else if(source == ex) {
				System.out.println("Nuking the swamp... bye bye!");
				Model.nukeSwamp();
			}
		}
		
	}
	
	/**
	 * update viewport's scale based on our slider value
	 * 
	 */
	public static void updateScale()
	{
		viewport.setScale(viewport.getMinRatio() + viewScale.getValue()*(maxscale-viewport.getMinRatio())/100);
	}
	
	/** increase slider scale value */
	static public void incrSliderScale()
	{
		int tick = 5;
		if(viewScale.getValue() + tick > 100) viewScale.setValue(100);
		else viewScale.setValue(viewScale.getValue() + tick);
	}
	
	/** decrease slider scale value */
	static public void decrSliderScale()
	{
		int tick = 5;
		if(viewScale.getValue() - tick < 0) viewScale.setValue(0);
		else viewScale.setValue(viewScale.getValue() - tick);
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
	 */
	@Override
	public void stateChanged(ChangeEvent arg0) {
		Object source = arg0.getSource();
		if (source==delay){
		    Controller.setTiming(delay.getValue()+1);
		} else if (source==viewScale) {
			updateScale();	
		} else {
		// source not delay
			if(source instanceof JSlider)
			{
			if(getRepoSlider((JSlider)source) >= 0) repoSliderChanged(getRepoSlider((JSlider)source), (JSlider)source);
			} // dealing with JSlider
		}
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */

	@Override
	public void actionPerformed(ActionEvent arg0) {
		Object source = arg0.getSource();
		if(source == playButton) {
		    if(Controller.getPlay()==true) {
				Controller.togglePlay();
				playButton.setText("Play");
		    } else {
		    	Controller.togglePlay();
				playButton.setText("Pause");
		    }
		} else if(source == saveButton) {	
			Setup.swampToFile(window);
		} else if(source == loadButton) {
			Setup.swampFromFile(window);
		} else if(source == labelsButton) {
			if(getShowLabels()) { setShowLabels(false); labelsButton.setText("Show Labels"); } else {
								  setShowLabels(true); labelsButton.setText("Hide Labels"); }
		} else if (source == menuButton) {
			toggleMainMenu();
		} else if(source == reproButton){
			if(reproFrame == null) openRepoBox(); else reproFrame.setVisible(true);
		} else {
			if(source instanceof JButton)
			{
			if(getRepoButton((JButton)source) >= 0) repoButtonClicked(getRepoButton((JButton)source), (JButton)source);
			} // dealing with JButton
		}
	}
	
	/**
	 * Toggle main menu.
	 */
	private void toggleMainMenu()
	{
		if(mmDialog == null) openMainMenu(); else {
			mmDialog.setLocation(window.getX()+window.getWidth()/2-mmDialog.getWidth()/2, window.getY()+window.getHeight()/2-mmDialog.getHeight()/2);
			mmDialog.setVisible(!mmDialog.isVisible());
			}
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
	 */
	@Override
	public void keyPressed(KeyEvent e) {
	//	System.out.println("key prs!" + e.getKeyCode());
		if(e.getKeyCode() == 27) {
		// escape pressed
			toggleMainMenu();
		}
	}

	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
	 */
	@Override
	public void keyReleased(KeyEvent e) {}

	/* (non-Javadoc)
	 * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
	 */
	@Override
	public void keyTyped(KeyEvent e) {
	//	System.out.println("key typed!" + e.getKeyCode());
	}

	@Override
	public void componentHidden(ComponentEvent arg0) {
		// needed to implement interface ComponentListener
	}

	@Override
	public void componentMoved(ComponentEvent arg0) {
		// needed to implement interface ComponentListener
	}

	@Override
	public void componentResized(ComponentEvent arg0) {
		updateScale();
	}

	@Override
	public void componentShown(ComponentEvent arg0) {
		// needed to implement interface ComponentListener
		
	}
}
