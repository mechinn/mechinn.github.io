/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.*;

/**
 * Subclass of DynamicGridItem which is for animals that cannot go outside the water area.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     DynamicGridItem
 */
public class WaterAnimal extends DynamicGridItem {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9182700497238428761L;

	/**
	 * Instantiates a new water animal.
	 */
	public WaterAnimal() { 
		this(0,0,0,0,0);
	}
	
	/**
	 * Instantiates a new water animal.
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 */
	public WaterAnimal(int IDin, int X, int Y,int getSpeed, int getScale){
		this(IDin,X,Y,getSpeed,getScale,"",12);
	}
	
	/**
	 * Instantiates a new water animal.
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getFrames the number of frames
	 */
	public WaterAnimal(int IDin, int X, int Y,int getSpeed, int getScale, int getFrames){
		this(IDin,X,Y,getSpeed,getScale,"",getFrames);
	}
	
	/**
	 * Instantiates a new water animal.
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getAction the action
	 * @param getFrames the number of frames
	 */
	public WaterAnimal(int IDin, int X, int Y,int getSpeed, int getScale, String getAction, int getFrames){
		super(IDin,X,Y,getSpeed,getScale,getAction,getFrames);
		setAllowedArea(Model.getWaterLoc());

		defaultAction = "swimming";
		
		if(!this.getAllowedArea().contains(this.getLoc())){
//			System.out.println("Oops, water animals can't start out on the land");
			Random generator = new Random();
			while(!this.getAllowedArea().contains(this.getLoc())){
				//For now, the window they can move in is smaller (easier to see if move is working right)
				int x = generator.nextInt(15000);//+100; //max would be (15,000)+1
				int y = generator.nextInt(15000);//+2000; //max would be (15,000)+1
				setLoc(x,y);
			}
//			System.out.println( this.getTypecode() + " at " + this.getLoc());
		}
	}
}
