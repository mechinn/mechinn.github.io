/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Controller part of MVC, all user interface and user modification of variables.
 *
 * @author  group2
 * @author  Michael Chinn <mechinn>
 * @author  Andrea Macartney <andmac>
 * @author  Samuel Schlachter <saschlac>
 * @author  Matthew Puterio <mputerio>
 * @author  Ryan Richardson <rsquared>
 *
 * @version %W% %E%
 *
 * @since   1.6
 *
 * @see     JFrame
 * @see	    ChangeListener
 * @see	    ActionListener
 */

import java.util.ArrayList;
import java.util.Collection;

/**
 * Controls the timing of any changes happening in model and subsequently the view
 * 
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 */
public class Controller{
	
	/** The timing - speed at which the simulation is run. */
	static int timing = 5;
    
    /** The play - is the simulation running? */
    static boolean play;
	
	/** The running - if the loop is running. Used to determine when an iteration has resolved*/
	private static boolean running = false;
	
	/** The view - where we see everything. */
	View view;
	
	/** The run - similar to play and run used for other applications. */
	static boolean run;
    
    /**
     * Constructor for user interface and control of program.
     *
     * @param mod    <code>Model</code> created for the controller.
     */
    public Controller(Model mod){
    	run = true;
		play = true;
		running = true;
		runSimulation();
    }
    
    /**
     * Instantiates a new controller.
     *
     * @param mod the mod
     * @param runSim the run sim
     */
    public Controller(Model mod, boolean runSim){
    	run = true;
		play = true;
		running = true;
    }
    
    /**
     * Exit - exits the simulation loop.
     */
    public static void exit() {
    	setAge(0);
    	run = false;
    	View.closeRepoBox();
    	SwampStatistics.hideStatsWindow();
    	
    }
	
	/**
	 * Sets the timing - the speed at which the simulation runs.
	 *
	 * @param time the new timing
	 */
	public static void setTiming(int time){timing = time;}
	
	/**
	 * Toggle play - loop keeps going but we don't progress the simulation .
	 */
	public static void togglePlay(){play = !play;}
	
	/**
	 * Gets the play - are we currently running the sim?.
	 *
	 * @return the play
	 */
	public static boolean getPlay(){return play;}
	
	/** The clear model - is the model clear?. */
	private static boolean clearModel = false;
	
	/**
	 * Sets the clear model.
	 *
	 * @param b the new clear model
	 */
	public static void setClearModel(boolean b)
	{
		clearModel = b;
	}
	
	/**
	 * Checks if is running.
	 *
	 * @return true, if is running
	 */
	public static boolean isRunning()
	{ return running; }
	
	/** The age of the simulation. */
	private static long age = 0;
	
	/**
	 * Gets the age.
	 *
	 * @return the age
	 */
	public static long getAge() { return age; } 
	public static void setAge(long a) { age = a; }
    /**
     * Run simulation - the main logical loop.
     */
    private void runSimulation() {
		view = new View();
		//Loop in case the user wants to pause movement:
		while(run) {
		    if(play) {
		    	for(DynamicGridItem item : Model.getItems()){
					if(item instanceof DynamicGridItem){
						if(item.isAlive()){
							if(age%(item.getSpeed()*1000*timing)==0){
								if(item.getGoal().x ==-1 && item.getGoal().y == -1)	
									item.changeGoal();
								if(item.goalReached()){
									//if action counter is less than 0 we have a goal that was just reached and we can perform a goalEvent
									if(item.getActionCounter()<0){
										item.startGoalEvent();
									// if it equals zero we have finished our interaction and we can find a new goal
									}
									else if(item.getActionCounter()==0){
										item.endGoalEvent();
										item.changeGoal();
										item.nextMove();
										item.moveItem();
									}
									// if the item is involved in an event we can have it 
									// do an incremental event as well as decrease the time
									// left in the interaction
									else{
										item.decreaseActionCounter();
										item.intermediateGoalEvent();
									}
								}
								else{
									item.moveAction(); //cycle frames to produce animation
									for(int j = 0; j < 2; j++)
										item.moveItem();
									item.nextMove();
								}
							}
						}
					}
				}
				if(age%100==0){
					cleanupBodies();
					Model.getItems().addAll(Model.birthQueue);
					Model.getItems().removeAll(Model.deathQueue);
					Model.birthQueue.clear();
				}
				if(age % 200000 == 0) { SwampStatistics.update(); }
				age++;
//				if(age%50==0)
					View.repaint();
				
		    } // while play
		    if(clearModel) { Model.clearAndAdd(); clearModel = false;}
		}
		view = null;
    }

    /**
     * Cleanup bodies - manages the death queue. Removes things that have been dead too long, 
     */
    static void cleanupBodies(){
		Collection<DynamicGridItem> dead = new ArrayList<DynamicGridItem>();
		for(DynamicGridItem item : Model.deathQueue){
			if(item.getAge()>200000){
				System.out.println("removing " + item);
				dead.add(item);
			}
			else{
				item.incrementAge();
			}
		}
		Model.deathQueue.removeAll(dead);
	}
}
