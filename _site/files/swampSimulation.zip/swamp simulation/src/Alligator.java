/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Specific AmphibiousAnimal subclass for model.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     AmphibiousAnimal
 */
public class Alligator extends AmphibiousAnimal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7697079893517397150L;

	/** The speed at which the alligator will move. */
	private static int speed = 4;
	
	/** The scale of the image. */
	private static int scale = 50;
	
	/** The counter. */
	private static int counter = 0;
	
	/** The reproduction rate. */
	private static int reproRate = 5;
	
	/** The action to print. */
	private static String action = "walking";
	
	/**
	 * Instantiates a new alligator.
	 *
	 * @param X the x location
	 * @param Y the y location
	 */
	public Alligator(int X, int Y){
		super(counter++,X,Y,speed,scale, action, 12); // walking = default
		favoriteFoods.add("Raccoon");
		favoriteFoods.add("Nutriarat");
		favoriteFoods.add("Perch");
		favoriteFoods.add("Heron");
		favoriteFoods.add("Opossum");
	}

	/**
	 * get the reproduction rate.
	 *
	 * @return the reproduction rate
	 * @see DynamicGridItem#getreproRate()
	 */
	public int getreproRate(){ return reproRate;}
	
	/**
	 * Sets the reproduction rate.
	 *
	 * @param reproIn the new reproduction rate
	 */
	public static void setreproRate(int reproIn){reproRate = reproIn;}

	/**
	 * add a new Alligator to the birth Queue.
	 *
	 * @see DynamicGridItem#reproduce()
	 */
	public void reproduce(){
		Model.addToBirthQueue(new Alligator(this.getXCoord(),this.getYCoord()));
		System.out.println("an Alligator is born");
	}
}
