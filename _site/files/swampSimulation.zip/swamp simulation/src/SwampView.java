/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.*;
import java.io.File;
import javax.swing.*;
import java.io.IOException;
import javax.imageio.ImageIO;

import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

/**
 * Main panel where all graphical items are displayed.
 * </br>Uses the following layers (from bottom to top):
 * </br>1. Water animals
 * </br>2. 50% transparent water
 * </br>3. Land/Amphibious animals
 * </br>4. 20% transparent trees
 * </br>5. Flying animals
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 *
 * @version %W% %E%
 *
 * @since   1.6
 *
 * @see     JLayeredPane
 */
public class SwampView extends JLayeredPane {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7527076406835402023L;
	
	/** The background. */
	public BufferedImage background;
	
	/** The land animal layer. */
	private AnimalLayer<LandAnimal> landAnimalLayer;
	
	/** The water animal layer. */
	private AnimalLayer<WaterAnimal> waterAnimalLayer;
	
	/** The flying animal layer. */
	private AnimalLayer<FlyingAnimal> flyingAnimalLayer;
	
	/** The water layer. */
	private WaterLayer waterLayer;
	
	/** The tree layer. */
	private TreesLayer treeLayer;
	
	/** The scale. */
	private double scale;
	
	/** The back width. */
	private int backWidth;
	//private int backHeigth;
	
	/**
	 * Sets up a new swamp view.
	 */
	public SwampView(){
		scale = 1;
		landAnimalLayer = new AnimalLayer<LandAnimal>(LandAnimal.class);
		waterAnimalLayer = new AnimalLayer<WaterAnimal>(WaterAnimal.class);
		flyingAnimalLayer = new AnimalLayer<FlyingAnimal>(FlyingAnimal.class);
		waterLayer = new WaterLayer();
		treeLayer = new TreesLayer();
		landAnimalLayer.setScale(scale);
		waterAnimalLayer.setScale(scale);
		flyingAnimalLayer.setScale(scale);
		waterLayer.setScale(scale);
		treeLayer.setScale(scale);
		
		//add(waterAnimalLayer,new Integer(1));
		add(waterAnimalLayer, new Integer(1));
		add(landAnimalLayer, new Integer(3));
		add(flyingAnimalLayer, new Integer(5));
		add(waterLayer,new Integer(2));
		add(treeLayer,new Integer(4));
		
		try {
		    background = ImageIO.read(new File("imgs/ground.png"));
		} catch (IOException ex) {
		    throw new RuntimeException("Could not open file: imgs/ground.png"); //if it fails tell the user
		}
		backWidth = background.getWidth();
		setPreferredSize(new Dimension(background.getWidth(),background.getHeight()));
	}

    /* (non-Javadoc)
     * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
     */
    @Override
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);
		Graphics2D g2D = (Graphics2D) g;
		setRenderingHints(g2D);
		AffineTransform xform = AffineTransform.getScaleInstance(scale,scale);
    	g2D.drawImage(background,xform,this);
	}
    
    /**
     * Sets the rendering hints for anti-aliasing.
     *
     * @param g the new rendering hints
     */
    public static void setRenderingHints(Graphics2D g) {
    	// turn on anti-aliasing
    	g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    	RenderingHints.VALUE_ANTIALIAS_ON);
    	g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
    	RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    	g.setRenderingHint(RenderingHints.KEY_RENDERING,
    	RenderingHints.VALUE_RENDER_QUALITY);
	}
    
    /**
     * Sets the scale for everything in the jlayeredpane.
     *
     * @param newScale the new scale
     */
    public void setScale(double newScale) {
    	scale = newScale;
    	landAnimalLayer.setScale(newScale);
		waterAnimalLayer.setScale(newScale);
		flyingAnimalLayer.setScale(newScale);
		waterLayer.setScale(newScale);
		treeLayer.setScale(newScale);
    	setPreferredSize(new Dimension((int)(background.getWidth()*scale),(int)(background.getHeight()*scale)));
    }
    
    /**
     * Gets the back width for the viewport.
     *
     * @return the back width
     */
    public int getBackWidth() {
    	return backWidth;
    }
}
