/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Subclass of WaterAnimal for specific animal.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     WaterAnimal
 */
public class Tadpole extends WaterAnimal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6119919715235779280L;

	/** The inital lifespan. */
	private static int initalLifespan = 2500;
	
	/** The speed. */
	private static int speed = 3;
	
	/** The scale. */
	private static int scale = 10;
	
	/** The counter. */
	private static int counter = 0;
	
	/** The parent frog. 1 = bullfrog 0 = treefrog*/
	private boolean parentFrog; // 1 = bullfrog 0 = treefrog

	/**
	 * Instantiates a new tadpole.
	 *
	 * @param X the x
	 * @param Y the y
	 */
	public Tadpole(int X, int Y){
		this(X, Y,DynamicGridItem.genRand(2)==1?"Bullfrog":"Treefrog");
	}

	/**
	 * Instantiates a new tadpole.
	 *
	 * @param X the x
	 * @param Y the y
	 * @param parent - am i a bullfrog or treefrog offspring?
	 */
	public Tadpole(int X, int Y, String parent){
		super(counter++,X,Y,speed,scale);
		favoriteFoods.add("Algae");
//		System.out.println("My parent was a " + parent + " I hope to be one some day. I expect to be " + getLifespan() + " old");
		if(parent=="Bullfrog"){
			NewImageLibrary.addClassImage(new Bullfrog(0,0)); // load frog img to avoid delay when tadpole turns into frog
			parentFrog = true;
		}
		else if(parent=="Treefrog"){
			NewImageLibrary.addClassImage(new Treefrog(0,0));
			parentFrog = false;
		}
	}

	/* (non-Javadoc)
	 * @see DynamicGridItem#getInitalLifespan()
	 */
	public int getInitalLifespan(){return initalLifespan;}

	// copy paste job from DGI = not good
	// we implemented tadpoles last minute
	/** change goal - mostly just removes the ability to find mates in goal seeking 
	 * @see DynamicGridItem#changeGoal()
	 */
	public void changeGoal(){
		int x = 0, y = 0;
		//if hungry look for food
		if(getHungry()){
			if(findPrey()){
				nextMove();
				this.setActionCounter(-1);
				return;
			}		
		}
		else if(DynamicGridItem.genRand(getmaxHunger())<getHunger()){
			//hungry = true;
			setHungry();
			setNewAction(" is hungry");
			return;
		}
		// otherwise we wander
		while(!this.getAllowedArea().contains(x,y)){
			x = DynamicGridItem.genRand(15000);
			y = DynamicGridItem.genRand(15000);
		}
		this.setGoal(x,y);
		updateLabelText();
		nextMove();
		this.setActionCounter(-1);
	}  

	/** moveAction - tadpole special case instead of dying when we're old we kill ourselves and become frogs
	 * 
	 * @see DynamicGridItem#moveAction()
	 */
	public void moveAction(){
		picIndex++;
		incrementAge();
		if(getAge()>getLifespan()){
			this.kill();
			setAge(199900);
			if(parentFrog)
				Model.addToBirthQueue(new Bullfrog(this.getXCoord(),this.getYCoord()));
			else
				Model.addToBirthQueue(new Treefrog(this.getXCoord(),this.getYCoord()));
//			System.out.println("a "+this.getTypecode()+" is turning into a frog");
		}
	}
}

