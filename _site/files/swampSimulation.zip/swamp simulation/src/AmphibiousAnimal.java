/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.*;

/**
 * DynamicGridItem subclass for all animals that can go on land and on water.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     DynamicGridItem
 */
public class AmphibiousAnimal extends DynamicGridItem {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2425089859560033307L;

	/**
	 * creates a new Amphibious animal with default 12 frames
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 */
	public AmphibiousAnimal(int IDin, int X, int Y,int getSpeed, int getScale){
		this(IDin, X, Y, getSpeed, getScale, "", 12);
	}
	
	/**
	 * Creates a new Amphibious animal with given frames
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getFrames the frames
	 */
	public AmphibiousAnimal(int IDin, int X, int Y,int getSpeed, int getScale, int getFrames){
		this(IDin, X, Y, getSpeed, getScale, "", getFrames);
	}
	
	/**
	 * creates a new Amphibious animal with given action string and default 12 frames
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getAction the action
	 */
	public AmphibiousAnimal(int IDin, int X, int Y,int getSpeed, int getScale, String getAction){
		this(IDin, X, Y, getSpeed, getScale, getAction, 12);
	}
	
	/**
	 * creates a new DynamicGridItem with Amphibious animal specifications as given
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getAction the action
	 * @param getFrames the frames
	 */
	public AmphibiousAnimal(int IDin, int X, int Y,int getSpeed, int getScale, String getAction, int getFrames){
		super(IDin,X,Y,getSpeed,getScale,getAction, getFrames);
		setAllowedArea(Model.getOtherLimits());

		if(!this.getAllowedArea().contains(this.getLoc())){
			Random generator = new Random();
			while(!this.getAllowedArea().contains(this.getLoc())){
				int x = generator.nextInt(15000);
				int y = generator.nextInt(15000);
				setLoc(x,y);
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see DynamicGridItem#doSetAction()
	 */
	public void doSetAction()
	{
		if(Model.getWaterLocation().contains(this.getLoc())) setAction("swimming");
		if(Model.getLandLocation().contains(this.getLoc())) setAction("walking");
	}
	
}

