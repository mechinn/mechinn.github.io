/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.JViewport;

/**
 * Customized JViewport to allow mouse interactions.
 * </br>The viewport views the SwampView and allows panning and zooming using a mouse scroll wheel
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 *
 * @version %W% %E%
 *
 * @since   1.6
 *
 * @see     JViewport
 * @see		MouseWheelListener
 * @see		MouseMotionListener
 * @see		MouseListener
 */
public class Viewport extends JViewport implements MouseWheelListener, MouseMotionListener, MouseListener  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -399089961207364214L;

	/** The swamp. */
	private static SwampView swamp;
	
	/** The scale. */
	private double scale;
	
	/** The click x. */
	private int clickX;
	
	/** The click y. */
	private int clickY;
	
	/**
	 * Instantiates a new viewport.
	 *
	 * @param getSwamp the get swamp
	 */
	public Viewport(SwampView getSwamp){
		setView(getSwamp);
		scale = 1;
		
		swamp = getSwamp;
		this.
		addMouseWheelListener(this);
		addMouseMotionListener(this);
		addMouseListener(this);
	}
    
	/** return minimum scale ratio */
	public double getMinRatio()
	{
		return (double)this.getWidth()/(double)swamp.getBackWidth();
	}
    
    /* (non-Javadoc)
     * @see java.awt.event.MouseWheelListener#mouseWheelMoved(java.awt.event.MouseWheelEvent)
     */
    @Override
	public void mouseWheelMoved(MouseWheelEvent arg0) {
		
		if(arg0.getWheelRotation() == -1) { // zoom in
			View.incrSliderScale();
		} else { // zoom out
			View.decrSliderScale();
		}
		
		//REALLY UGLY code to zoom on the cursor :( any ideas?
//		int maxX = ((int)(swamp.getPreferredSize().getWidth())-this.getWidth());
//		int maxY = ((int)(swamp.getPreferredSize().getHeight())-this.getHeight());
//		Point mouseLoc = MouseInfo.getPointerInfo().getLocation();
//		Point viewLoc = this.getLocationOnScreen();
//		int displayLocX = Math.min(maxX, mouseLoc.x-viewLoc.x);
//		int displayLocY = Math.min(maxY,mouseLoc.y-viewLoc.y);
//		Point swampLoc = swamp.getLocation();
//		setViewPosition(new Point(displayLocX,displayLocY));
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseClicked(MouseEvent arg0) {
		
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseEntered(MouseEvent arg0) {}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseExited(MouseEvent arg0) {}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	@Override
	public void mousePressed(MouseEvent arg0) {
		clickX = arg0.getX();
		clickY = arg0.getY();
		setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		clickX = 0;
		clickY = 0;
		setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseDragged(MouseEvent arg0) {
		Point viewLoc = this.getViewPosition();
		int dragX = arg0.getX();
		int dragY = arg0.getY();
		viewLoc.x = (int) (viewLoc.x-(dragX-clickX)*scale);
		viewLoc.y = (int) (viewLoc.y-(dragY-clickY)*scale);
		clickX = dragX;
		clickY = dragY;
		if(viewLoc.x<0){
			viewLoc.x=0;
		}
		if(viewLoc.y<0){
			viewLoc.y=0;
		}
		int maxX = ((int)(swamp.getPreferredSize().getWidth())-this.getWidth());
		int maxY = ((int)(swamp.getPreferredSize().getHeight())-this.getHeight());
		if(viewLoc.x>maxX){
			viewLoc.x=maxX;
		}
		if(viewLoc.y>maxY){
			viewLoc.y=maxY;
		}
		setViewPosition(viewLoc);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseMoved(MouseEvent arg0) {}
	
	public void setScale(double newScale) {
		scale = newScale;
		swamp.setScale(scale);
		setViewSize(new Dimension((int)(swamp.getPreferredSize().getWidth()), (int)(swamp.getPreferredSize().getHeight())));
	}
	
	/**
	 * Gets the scale.
	 *
	 * @return the scale
	 */
	public double getScale() {
		return scale;
	}
}
