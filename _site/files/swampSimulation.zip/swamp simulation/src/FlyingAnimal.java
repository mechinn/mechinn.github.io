/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.*;

/**
 * DynamicGridItem subclass that can fly above everything in the swamp.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     DynamicGridItem
 */
public class FlyingAnimal extends DynamicGridItem {
	
	
/**
	 * 
	 */
	private static final long serialVersionUID = 2667801505863784958L;

	/**
	 * Sets up a new flying animal.
	 */
	public FlyingAnimal() {
		this(0,0,0,0,0);
	}
	
	/**
	 * Sets up a new flying animal with specific id number, x, y, speed, and scale
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 */
	public FlyingAnimal(int IDin, int X, int Y,int getSpeed, int getScale) {
		this(IDin, X, Y, getSpeed, getScale, "", 12);
	}
	
	/**
	 * Sets up a new flying animal with an addition of specific number of frames
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getFrames the number of frames
	 */
	public FlyingAnimal(int IDin, int X, int Y,int getSpeed, int getScale, int getFrames) {
		this(IDin, X, Y, getSpeed, getScale, "", getFrames);
	}
	
	/**
	 * Sets up a new flying animal.
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getAction the action text
	 * @param getFrames the number of frames
	 */
	public FlyingAnimal(int IDin, int X, int Y,int getSpeed, int getScale, String getAction, int getFrames){
		super(IDin,X,Y,getSpeed,getScale,getAction,getFrames);
		setAllowedArea(Model.getOtherLimits());
		
		defaultAction = "flying";
		
		if(!this.getAllowedArea().contains(this.getLoc())){
			Random generator = new Random();
			while(!this.getAllowedArea().contains(this.getLoc())){
				//For now, the window they can move in is smaller (easier to see if move is working right)
				int x = generator.nextInt(15000);//+100; //max would be (15,000)+1
				int y = generator.nextInt(15000);//+2000; //max would be (15,000)+1
				setLoc(x,y);
			}
		}
	}
}

