/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.geom.AffineTransform;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.imageio.ImageIO;

/**
 * Image Library we can call which will either get new images for us or point us to the images it already loaded for what we asked for.
 *
 * @author  group2
 * @author  Michael Chinn <mechinn>
 * @author  Andrea Macartney <andmac>
 * @author  Samuel Schlachter <saschlac>
 * @author  Matthew Puterio <mputerio>
 * @author  Ryan Richardson <rsquared>
 *
 * @version %W% %E%
 *
 * @since   1.6
 */
public class NewImageLibrary {
	
	/** The basedir. */
	static private String basedir = "imgs";
	
	/** The suffix. */
	static private String suffix = ".png";
	
	/** The directions. */
	static private String[] directions = {"N","NE","SE","S","SW","NW"}; // ORDER IS IMPORTANT!
	
	/** The ss img file. */
	static private String ssImgFile = "ss.png"; // "swamp sex" image.  shown in place of normal animal animation while animal is mating.  
												// this is an image (instead of shape drawn with java) just in case we want to put something else here
	/** The images. */
												static HashMap<String,BufferedImage[][]> images = new HashMap<String,BufferedImage[][]>();
	
	/** The ss img. */
	static BufferedImage ti, ti2, ssImgOrig, ssImg;
	
	/** The sia. */
	static BufferedImage[] sia;
	
	static {
	try {
		sia = new BufferedImage[12]; // just because we need to return an array later...
		ssImgOrig = ImageIO.read(new File(basedir + "/" + ssImgFile));
	} catch (IOException e) {			// the above code is static and bad.. i know... but this is just for fun anyway
		System.out.println("Couldn't load reproduction image! (is that a good thing?)");
	}
	}
	
	/**
	 * Gets the image.
	 *
	 * @param d the d
	 * @return the image
	 */
	public static BufferedImage[] getImage(DynamicGridItem d)
	{
		String action;
		int move = d.getMove();
		if(move < 1 || move > directions.length) { move = d.getLastMove(); }
		if(!d.getAction().equals("")) action = "_" + d.getAction(); else action="";
		if(!images.containsKey(d.getTypecode().toLowerCase()+action))  action="";  // if we can't load action specific image, try using default 
		if(!images.containsKey(d.getTypecode().toLowerCase()+action)) { /*System.out.println("Can't find " + name + " in image library!");*/
			// can't find default action, now try loading original specific action
			if(!addClassImage(d)) { return null; } else { action = "_" + d.getAction(); } }
		if(move < 1 || move > directions.length) { return null; } // maybe handle these errors better?
		if(d.getReproducing() && ssImgOrig != null) { ssImg = getScaled(ssImgOrig,d.getSize()); for(int i = 0; i < 12; i++) sia[i] = ssImg; return sia; }
		return images.get(d.getTypecode().toLowerCase()+action)[move-1];
	}
	
	/**
	 * Adds the class image.
	 *
	 * @param d the d
	 * @return true, if successful
	 */
	public static boolean addClassImage(DynamicGridItem d)
	{
		String action;
		if(!d.getAction().equals("")) action = "_" + d.getAction(); else action="";
		File dir = new File(basedir + "/" + d.getTypecode().toLowerCase() + action);
		if(!dir.exists()) action="";
		String aw = d.getAction().equals("") ? "" : " (" + d.getAction() + ")"; 
		if(images.containsKey(d.getTypecode().toLowerCase()+action)) { /* System.out.println(" already loaded!"); */ return true; } // don't want to re-load the image if we already have it
		System.out.print("Loading graphics for " + d.getTypecode() + aw + "...");
		BufferedImage[][] itemimg = new BufferedImage[6][12];

		try {
			for(int i = 0; i < directions.length; i++) 
			{
				//System.out.println("trying to load " +basedir + "/" + d.getTypecode().toLowerCase() + action + "/" + d.getTypecode().toLowerCase() + action + "_" + directions[i] + suffix);
				ti = ImageIO.read(new File(basedir + "/" + d.getTypecode().toLowerCase() + action + "/" + d.getTypecode().toLowerCase() + action + "_" + directions[i] + suffix));
				int sw = ti.getWidth()/d.getFrames();
				for(int j = 0; j < d.getFrames(); j++) {
					ti2 = ti.getSubimage(j * sw, 0, sw, ti.getHeight());
					itemimg[i][j] = getScaled(ti2,d.getSize());
				}
			}
			images.put(d.getTypecode().toLowerCase()+action, itemimg);
			System.out.println();
		} catch(IOException ie) {
			//System.out.println("failed to load: " + d.getTypecode() + aw + " graphics");
			System.out.println(" failed!");
			return false;
		}
		ti2 = null;
		ti = null;
		return true;
	}
	
	/**
	 * Gets the scaled.
	 *
	 * @param bi the bi
	 * @param scale the scale
	 * @return the scaled
	 */
	private static BufferedImage getScaled(BufferedImage bi, int scale)
	{
		AffineTransform xform = new AffineTransform();
		xform.scale((double)scale/100,(double)scale/100);
		AffineTransformOp op = new AffineTransformOp(xform, AffineTransformOp.TYPE_BILINEAR);
		return op.filter(bi,null);
	}
}
