/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

//******* IT'S 7:16 AM on the day this is due... sorry that the code is static and terrible.  we just really wanted this feature!
/// i promise that i know how to write decent (somewhat decent?) code!
public class SwampStatistics {

	static JFrame sw;
	
	static JLabel swampAgeLabelV;
	static JLabel totalAnimalsLabelV;
	static JLabel totalSpeciesLabelV;
	static JLabel recentlyDiedLabelV;
	static JLabel curMatingLabelV;
	static JLabel curAttackLabelV;
	static JLabel curEatingLabelV;
	static JLabel totalLandLabelV;
	static JLabel totalWaterLabelV;
	static JLabel totalAmphiLabelV;
	static JLabel totalFlyingLabelV;
	static JLabel curWanderLabelV;
	
	@SuppressWarnings("rawtypes")
	static Class[] animals;
	static JLabel[] animalLabelsV;
	
	static {
		
		Font curFont;

		sw = new JFrame("Swamp Statistics");
		sw.setSize(350,300);
		
		swampAgeLabelV = new JLabel();
		swampAgeLabelV.setForeground(Color.blue);
		
		totalAnimalsLabelV = new JLabel();
		totalAnimalsLabelV.setForeground(Color.blue);
		
		totalSpeciesLabelV = new JLabel();
		totalSpeciesLabelV.setForeground(Color.blue);
		
		recentlyDiedLabelV = new JLabel();
		recentlyDiedLabelV.setForeground(Color.blue);
		
		curMatingLabelV = new JLabel();
		curMatingLabelV.setForeground(Color.blue);
		
		curAttackLabelV = new JLabel();
		curAttackLabelV.setForeground(Color.blue);
		
		curEatingLabelV = new JLabel();
		curEatingLabelV.setForeground(Color.blue);
		
		totalLandLabelV = new JLabel();
		totalLandLabelV.setForeground(Color.blue);
		
		totalWaterLabelV = new JLabel();
		totalWaterLabelV.setForeground(Color.blue);
		
		totalAmphiLabelV = new JLabel();
		totalAmphiLabelV.setForeground(Color.blue);
		
		totalFlyingLabelV = new JLabel();
		totalFlyingLabelV.setForeground(Color.blue);
		
		curWanderLabelV = new JLabel();
		curWanderLabelV.setForeground(Color.blue);
		
		animals = Setup.getAnimals();
		
		JLabel animalLabels[] = new JLabel[animals.length];
		animalLabelsV = new JLabel[animals.length];
		
		JLabel swampAgeLabel = new JLabel("Swamp Age: ",JLabel.RIGHT);
		curFont = swampAgeLabel.getFont();
		swampAgeLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));	
		
		JLabel totalAnimalsLabel = new JLabel("Total Animals: ",JLabel.RIGHT);
		curFont = totalAnimalsLabel.getFont();
		totalAnimalsLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));	
		
		JLabel totalSpeciesLabel = new JLabel("Total Species: ",JLabel.RIGHT);
		curFont = totalSpeciesLabel.getFont();
		totalSpeciesLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));	
		
		JLabel curMatingLabel = new JLabel("Mating: ",JLabel.RIGHT);
		curFont = curMatingLabel.getFont();
		curMatingLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));	
		
		JLabel curEatingLabel = new JLabel("Hungry: ",JLabel.RIGHT);
		curFont = curEatingLabel.getFont();
		curEatingLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));	
		
		JLabel curAttackLabel = new JLabel("Attacking: ",JLabel.RIGHT);
		curFont = curAttackLabel.getFont();
		curAttackLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));	
		
		JLabel recentlyDiedLabel = new JLabel("Recently Died: ",JLabel.RIGHT);
		curFont = recentlyDiedLabel.getFont();
		recentlyDiedLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));
			
		JLabel curWanderLabel = new JLabel("Wandering: ",JLabel.RIGHT);
		curFont = curWanderLabel.getFont();
		curWanderLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));	
		
		JLabel totalLandLabel = new JLabel("Land: ",JLabel.RIGHT);
		curFont = totalLandLabel.getFont();
		totalLandLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));		
		
		JLabel totalWaterLabel = new JLabel("Water: ",JLabel.RIGHT);
		curFont = totalWaterLabel.getFont();
		totalWaterLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));
		
		JLabel totalAmphiLabel = new JLabel("Amphibious: ",JLabel.RIGHT);
		curFont = totalAmphiLabel.getFont();
		totalAmphiLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));
		
		JLabel totalFlyingLabel = new JLabel("Flying: ",JLabel.RIGHT);
		curFont = totalFlyingLabel.getFont();
		totalFlyingLabel.setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));
		
		
		JPanel animalpanel = new JPanel(new GridLayout(animals.length,2));
		for(int i = 0; i < animals.length; i++) {
			animalLabels[i] = new JLabel(animals[i].getName() + ": ", JLabel.RIGHT);
			curFont = animalLabels[i].getFont();
			animalLabels[i].setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));
			animalLabelsV[i] = new JLabel("0");
			curFont = animalLabelsV[i].getFont();
			animalLabelsV[i].setFont(new Font(curFont.getFontName(), curFont.getStyle(), 10));
			animalLabelsV[i].setForeground(Color.red);
			animalpanel.add(animalLabels[i]);
			animalpanel.add(animalLabelsV[i]);
		}
		
		JPanel mp = new JPanel(new BorderLayout());
		
		
		
		JPanel sp = new JPanel(new GridLayout(0,2));
		
		sp.add(swampAgeLabel);
		sp.add(swampAgeLabelV);
		
		sp.add(totalAnimalsLabel);
		sp.add(totalAnimalsLabelV);
		
		sp.add(totalSpeciesLabel);
		sp.add(totalSpeciesLabelV);
		
		sp.add(curMatingLabel);
		sp.add(curMatingLabelV);
		
		sp.add(curEatingLabel);
		sp.add(curEatingLabelV);
		
		sp.add(curAttackLabel);
		sp.add(curAttackLabelV);
		
		sp.add(recentlyDiedLabel);
		sp.add(recentlyDiedLabelV);
		
		sp.add(curWanderLabel);
		sp.add(curWanderLabelV);
		
		sp.add(totalLandLabel);
		sp.add(totalLandLabelV);
		
		sp.add(totalWaterLabel);
		sp.add(totalWaterLabelV);
		
		sp.add(totalAmphiLabel);
		sp.add(totalAmphiLabelV);
		
		sp.add(totalFlyingLabel);
		sp.add(totalFlyingLabelV);
		
		mp.add("West",sp);
		mp.add("East",animalpanel);
		
		sw.add(mp);
		update();
	}
	
	public static void showStatsWindow()
	{
		sw.setVisible(true);
	}
	
	public static void hideStatsWindow()
	{
		sw.setVisible(false);
	}
	
	public static void update()
	{
		swampAgeLabelV.setText(new Long(Controller.getAge()/5000000).toString() + " SU");
		totalAnimalsLabelV.setText(new Integer(Model.totalAnimals()).toString());
		totalSpeciesLabelV.setText(new Integer(Model.totalSpecies()).toString());
		recentlyDiedLabelV.setText(new Integer(Model.countRecentlyDied()).toString());
		curMatingLabelV.setText(new Integer(Model.countMating()).toString());
		curAttackLabelV.setText(new Integer(Model.countAttacking()).toString());
		curEatingLabelV.setText(new Integer(Model.countHungry()).toString());
		curWanderLabelV.setText(new Integer(Model.countWandering()).toString());
		totalLandLabelV.setText(new Integer(Model.countLandAnimals()).toString());
		totalWaterLabelV.setText(new Integer(Model.countWaterAnimals()).toString());
		totalAmphiLabelV.setText(new Integer(Model.countAmphiAnimals()).toString());
		totalFlyingLabelV.setText(new Integer(Model.countFlyingAnimals()).toString());
		
		for(int i = 0; i < animals.length; i++)
			animalLabelsV[i].setText(new Integer(Model.countAnimal(animals[i].getName().toString())).toString());
		
	}
	
}
