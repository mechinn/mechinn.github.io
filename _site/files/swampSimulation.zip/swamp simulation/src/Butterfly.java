/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Specific FlyingAnimal for model.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     FlyingAnimal
 */
public class Butterfly extends FlyingAnimal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7098988095202429162L;

	/** The speed. */
	private static int speed = 3;
	
	/** The scale. */
	private static int scale = 10;
	
	/** The counter. */
	private static int counter = 0;
	
	/** The reproduction rate. */
	private static int reproRate = 5;

	/**
	 * Instantiates a new butterfly.
	 *
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 */
	public Butterfly(int X, int Y){
		super(counter++,X,Y,speed,scale);
		favoriteFoods.add("Flower");
	}

	/* (non-Javadoc)
	 * @see DynamicGridItem#getreproRate()
	 */
	public int getreproRate(){ return reproRate;}
	
	/**
	 * Sets the reproduction rate.
	 *
	 * @param reproIn the new reproduction rate
	 */
	public static void setreproRate(int reproIn){reproRate = reproIn;}

	/* (non-Javadoc)
	 * @see DynamicGridItem#reproduce()
	 */
	public void reproduce(){
		Model.addToBirthQueue(new Butterfly(this.getXCoord(),this.getYCoord()));
		System.out.println("a Butterfly is born");
	}
}
