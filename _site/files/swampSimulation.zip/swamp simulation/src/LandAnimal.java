/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.Serializable;
import java.util.*;

/**
 * Subclass of DynamicGridItem that is for all animals that walk on the ground and not in water in the simulation.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     Serializable
 */
public class LandAnimal extends DynamicGridItem {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5867897144332477186L;

	/**
	 * Sets up a new land animal.
	 */
	public LandAnimal() {
		this(0,0,0,0,0);
	}
	
	/**
	 * Sets up a new land animal with specific id number, x, y, speed, and scale.
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 */
	public LandAnimal(int IDin, int X, int Y,int getSpeed, int getScale){
		this(IDin, X, Y, getSpeed, getScale, "",12);
	}
	
	/**
	 * Sets up a new land animal with an addition of specific number of frames.
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getFrames the number of frames
	 */
	public LandAnimal(int IDin, int X, int Y,int getSpeed, int getScale, int getFrames){
		this(IDin, X, Y, getSpeed, getScale, "",getFrames);
	}
	
	/**
	 * Sets up a new land animal with an addition of action string.
	 *
	 * @param IDin the ID number
	 * @param X the x coordinate
	 * @param Y the y coordinate
	 * @param getSpeed the speed
	 * @param getScale the scale
	 * @param getAction the action string
	 * @param getFrames the number of frames
	 */
	public LandAnimal(int IDin, int X, int Y,int getSpeed, int getScale, String getAction, int getFrames){
		super(IDin,X,Y,getSpeed,getScale,getAction,getFrames);
		setAllowedArea(Model.getLandLoc());

		defaultAction = "walking";
		
		if(!this.getAllowedArea().contains(this.getLoc())){
//			System.out.println("Oops, land animals can't start out in the water");
			Random generator = new Random();
			while(!this.getAllowedArea().contains(this.getLoc())){
				//For now, the window they can move in is smaller (easier to see if move is working right)
				int x = generator.nextInt(15000);//+100; //max would be (15,000)+1
				int y = generator.nextInt(15000);//+2000; //max would be (15,000)+1
				setLoc(x,y);
			}
//			System.out.println(this.getTypecode() + " at " + this.getLoc());
		}
	}
}
