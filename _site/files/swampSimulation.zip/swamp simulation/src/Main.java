/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Starting function of program.
 *
 * @author  group2
 * @author  Michael Chinn <mechinn>
 * @author  Andrea Macartney <andmac>
 * @author  Samuel Schlachter <saschlac>
 * @author  Matthew Puterio <mputerio>
 * @author  Ryan Richardson <rsquared>
 *
 * @version %W% %E%
 *
 * @since   1.6
 */
public class Main {
    
    /**
     * Starting function of program.
     *
     * @param args   arguments given by user for height, width and depth of model.
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @SuppressWarnings("null")
	public static void main(String args[]) throws IOException {
		Model model = null;
    	Setup setup = null;
    	boolean debug = false;
    	while(true){    		
			if(args.length==1){
				if(args[0].trim().equals("debug")){
					model = new Model(16000,16000);
					debug = true;
				} else {
					Map<String, Integer> m = new HashMap<String, Integer>();
					parser(args[0],m);
				    model = new Model(16000,16000);
				    setup = new Setup(m);
				}
			}
			//This allows the user to customize the Controller size at the command line:
			else if(args.length==2){
				model = new Model(Integer.parseInt(args[0].trim()),Integer.parseInt(args[1].trim()));
				setup = new Setup();
			} else if(args.length==3) {
					Map<String, Integer> m = new HashMap<String, Integer>();
					parser(args[0],m);
				    model = new Model(Integer.parseInt(args[1].trim()),Integer.parseInt(args[2].trim()));
				    setup = new Setup(m);
	    	} else {
				model = new Model(16000,16000);
				setup = new Setup();
			}
			if(!debug){
				while(!setup.done()) { try { Thread.currentThread();
				Thread.sleep(1000); } catch (InterruptedException ie) {} }
				setup = null;
			} else {
				doDebugInit();
			}
			new Controller(model);
			model = null;
			setup = null;
			debug = false;
    	}
    }
    
    /**
     * sets up the model with predefined items.
     */
    private static void doDebugInit(){
		for(int i=1;i<=4;++i){
			// fish
			Model.addItem(new Catfish(0,0));
			Model.addItem(new Perch(0,0));
			Model.addItem(new Tadpole(0,0));
			//land
			Model.addItem(new Mouse(0,0));
			Model.addItem(new Heron(0,0));
			Model.addItem(new Treefrog(0,0));
			Model.addItem(new Snake(0,0));
			Model.addItem(new Nutriarat(0,0));
			Model.addItem(new Raccoon(0,0));
			Model.addItem(new Slug(0,0));
			Model.addItem(new Salamander(0,0));
			Model.addItem(new Turtle(0,0));
			//amphibious 
//    		Model.addItem(new Alligator(0,0));
			Model.addItem(new Bullfrog(0,0));
			//flying
			Model.addItem(new Bee(0,0));
			Model.addItem(new Butterfly(0,0));
			Model.addItem(new Moth(0,0));
			Model.addItem(new Fly(0,0));
			Model.addItem(new Mosquitoes(0,0));
			Model.addItem(new Butterfly(0,0));
			//plants
			for(int j=1;j<=7;j++){	
				Model.addItem(new Flower(0,0));
			}
		}
    }
    
    /**
     * Parser for CSV.
     *
     * @param filename the CSV filename
     * @param m the map
     * @throws FileNotFoundException the file not found exception
     */
    static void parser(String filename,Map<String, Integer> m) throws FileNotFoundException {
    	m.put("Alligator", 0);
		m.put("Bee", 0);
		m.put("Alligator", 0);
		m.put("Bee", 0);
		m.put("Bullfrog", 0);
		m.put("Butterfly", 0);
		m.put("Catfish", 0);
		m.put("Fly", 0);
		m.put("Heron", 0);
		m.put("Mosquitoes", 0);
		m.put("Moth", 0);
		m.put("Mouse", 0);
		m.put("Nutriarat", 0);
		m.put("Perch", 0);
		m.put("Raccoon", 0);
		m.put("Salamander", 0);
		m.put("Slug", 0);
		m.put("Snake", 0);
		m.put("Tadpole", 0);
		m.put("Treefrog", 0);
		m.put("Turtle", 0);
		m.put("Plant", 0);
		m.put("Crayfish", 0);
		m.put("Duck", 0);
		System.out.println(filename.trim());
		//Note that FileReader is used, not File, since File is not Closeable
	    Scanner scanner = new Scanner(new FileReader(new File(filename.trim())));
	    try {
		    while ( scanner.hasNextLine() ){
		    	Scanner line = new Scanner(scanner.nextLine());
		    	line.useDelimiter(",");
			    String name = line.next();
			    int number = Integer.parseInt(line.next());
			    if (number<0){
			    	number = 0;
			    }
			    System.out.println(name+" = "+number);
			    m.put(name, number);
		    }
	    } finally {
			//ensure the underlying stream is always closed
			//this only has any effect if the item passed to the Scanner
			//constructor implements Closeable (which it does in this case).
			scanner.close();
		}
    }
}
