/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ConcurrentModificationException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 * JPanel that shows a minature version of everything in simulation.
 * </br></br>Shows background, variable sized points color coded as follows:
 * </br></br>Pink, variable vegetation(flowers)
 * </br>Cyan, Amphibious Animals
 * </br>Green, Land Animals
 * </br>Blue, Water Animals
 * </br>White, Flying Animals
 * </br>Red, Dead Animals
 * </br></br>Also Shows a white box of what the user can see through the main view
 * </br>When a mouse is on the JPanel a yellow box will follow it showing the view the user would see if they clicked
 * </br>Clicking/Dragging the mouse will change the main view to the location shown by the yellow box
 * </br>Using a mouse's scroll wheel will zoom the main view in and out
 *
 * @author  group2
 * @author  Michael Chinn <mechinn>
 * @author  Andrea Macartney <andmac>
 * @author  Samuel Schlachter <saschlac>
 * @author  Matthew Puterio <mputerio>
 * @author  Ryan Richardson <rsquared>
 *
 * @version %W% %E%
 *
 * @since   1.6
 * 
 * @see JPanel
 * @see MouseListener
 * @see MouseMotionListener
 */
public class MiniMap extends JPanel implements MouseListener, MouseMotionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5764651743968635791L;

	/** The map. */
	private BufferedImage map;
	
	/** The view. */
	private Viewport view;
	
	/** The scale. */
	private double scale;
	
	/** The mouse x coordinate. */
	private int mouseX;
	
	/** The mouse y coordinate. */
	private int mouseY;
	
	/** If the mouse is inside. */
	private boolean mouseInside;
	
	/** The x coordinate of the box. */
	private int boxLocX;
	
	/** The y coordinate of the box. */
	private int boxLocY;
	
	/** The swamp scale. */
	private double swampScale;
	
	/**
	 * Sets up a new mini map.
	 *
	 * @param getView the get view
	 */
	public MiniMap(Viewport getView) {
		view = getView;
		scale = .1;
		try {
		    map = ImageIO.read(new File("imgs/ground.png"));
		} catch (IOException ex) {
		    throw new RuntimeException("Could not open file: imgs/ground.png"); //if it fails tell the user
		}
		AffineTransform xform = AffineTransform.getScaleInstance(scale, scale);
		AffineTransformOp op = new AffineTransformOp(xform, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
		map = op.filter(map, null);
		setPreferredSize(new Dimension(map.getWidth(),map.getHeight()));
		
		addMouseWheelListener(view);
		addMouseMotionListener(this);
		addMouseListener(this);
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	@Override
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);
		Graphics2D g2D = (Graphics2D) g;
		setRenderingHints(g2D);
    	g2D.drawImage(map,0,0,this);
    	try {
	    	for(DynamicGridItem item : Model.getItems()){
	    		if (item instanceof Flower){
	    			g2D.setColor(Color.pink);
	    		}else if(item instanceof AmphibiousAnimal) {
	    			g2D.setColor(Color.cyan);
	    		} else if (item instanceof LandAnimal){
	    			g2D.setColor(Color.green);
	    		} else if (item instanceof WaterAnimal){
	    			g2D.setColor(Color.blue);
	    		} else if (item instanceof FlyingAnimal) {
	    			g2D.setColor(Color.white);
	    		} else {
	    			g2D.setColor(Color.yellow);
	    		}
	    		g2D.fillOval((int)(item.getXCoord()/10*scale), (int)(item.getYCoord()/10*scale), (int)(item.getSize()*scale), (int)(item.getSize()*scale));
	    	}
    	} catch (ConcurrentModificationException e) {  
            System.out.println("Something is being modified so we cant display it, wait a cycle");
        }  
    	g2D.setColor(Color.red);
		for(DynamicGridItem item : Model.deathQueue){
			g2D.fillOval((int)(item.getXCoord()/10*scale), (int)(item.getYCoord()/10*scale), (int)(item.getSize()*scale), (int)(item.getSize()*scale));
		}
		g2D.setColor(Color.white);
		Point viewLoc = view.getViewPosition();
		swampScale = view.getScale();
		Dimension viewSize = view.getViewSize();
		Dimension seeView = view.getExtentSize();
		int boxWidth = (int)(map.getWidth()*seeView.getWidth()/viewSize.getWidth());
		int boxHeight = (int)(map.getHeight()*seeView.getHeight()/viewSize.getHeight());
		g2D.drawRect((int)(viewLoc.getX()/swampScale*scale),(int)(viewLoc.getY()/swampScale*scale),boxWidth,boxHeight);
		if(mouseInside) {
			g2D.setColor(Color.yellow);
			boxLocX = (int)((mouseX-boxWidth/2));
			if(boxLocX<0){
				boxLocX = 0;
			}
			if(boxLocX+boxWidth>map.getWidth()) {
				boxLocX = map.getWidth()-boxWidth;
			}
			boxLocY = (int)((mouseY-boxHeight/2));
			if(boxLocY<0){
				boxLocY = 0;
			}
			if(boxLocY+boxHeight>map.getHeight()) {
				boxLocY = map.getHeight()-boxHeight;
			}
			g2D.drawRect(boxLocX,boxLocY,boxWidth,boxHeight);
		}
	}
    
    /**
     * Sets the rendering hints for antialiasing.
     *
     * @param g the new rendering hints
     */
    public static void setRenderingHints(Graphics2D g) {
    	// turn on anti-aliasing
    	g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    	RenderingHints.VALUE_ANTIALIAS_ON);
    	g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
    	RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    	g.setRenderingHint(RenderingHints.KEY_RENDERING,
    	RenderingHints.VALUE_RENDER_QUALITY);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseClicked(MouseEvent arg0) {
		view.setViewPosition(new Point((int)(boxLocX/scale*swampScale),(int)(boxLocY/scale*swampScale)));
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseEntered(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
		mouseInside = true;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseExited(MouseEvent arg0) {
		mouseX = 0;
		mouseY = 0;
		mouseInside = false;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	@Override
	public void mousePressed(MouseEvent arg0) {}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseReleased(MouseEvent arg0) {}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseDragged(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
		view.setViewPosition(new Point((int)(boxLocX/scale*swampScale),(int)(boxLocY/scale*swampScale)));
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
	 */
	@Override
	public void mouseMoved(MouseEvent arg0) {
		mouseX = arg0.getX();
		mouseY = arg0.getY();
	}
}
