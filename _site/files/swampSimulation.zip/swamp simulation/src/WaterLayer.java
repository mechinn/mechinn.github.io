/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 * JPanel which displays an overlay of water which is half transparent to give the effect of underwater.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     JPanel
 */
public class WaterLayer extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8948500714746304180L;
	
	/** The scale. */
	private double scale;
	
	/** The water buffered image. */
	public static BufferedImage water;
	
	/**
	 * Sets up a new water layer.
	 */
	public WaterLayer() {
		setSize(Model.height,Model.width);
		setOpaque(false);
		try {
			water = ImageIO.read(new File("imgs/water.png"));
		} catch (IOException ex) {
		    throw new RuntimeException("Could not open file: imgs/water.png"); //if it fails tell the user
		}
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	@Override
    public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2D = (Graphics2D) g;
		setRenderingHints(g2D);
		g2D.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
		AffineTransform xform = AffineTransform.getScaleInstance(scale,scale);
    	g2D.drawImage(water,xform,this);
	}
	
	/**
	 * Sets the rendering hints.
	 *
	 * @param g the new rendering hints
	 */
	public static void setRenderingHints(Graphics2D g) {
    	// turn on anti-aliasing
    	g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    	RenderingHints.VALUE_ANTIALIAS_ON);
    	g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
    	RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    	g.setRenderingHint(RenderingHints.KEY_RENDERING,
    	RenderingHints.VALUE_RENDER_QUALITY);
	}

	/**
	 * Sets the scale.
	 *
	 * @param newScale the new scale
	 */
	public void setScale(double newScale) {
		scale = newScale;
	}
}
