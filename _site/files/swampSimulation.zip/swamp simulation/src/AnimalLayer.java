/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.util.ConcurrentModificationException;

import javax.swing.JPanel;

/**
 * JPanel that has a type that extends a DynamicGridItem for all variable items in the simulation
 * </br></br>Usage:
 * </br>landAnimalLayer = new AnimalLayer<LandAnimal>(LandAnimal.class);
 * </br>waterAnimalLayer = new AnimalLayer<WaterAnimal>(WaterAnimal.class);
 * </br>flyingAnimalLayer = new AnimalLayer<FlyingAnimal>(FlyingAnimal.class);
 *
 * @param <T> the type of DynamicGridItem
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     JPanel
 * @see     DynamicGridItem
 */
public class AnimalLayer<T extends DynamicGridItem> extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7660870747609750843L;

	/** The pics. */
	private BufferedImage[] pics;
	
	/** for try/catch. */
	private T t;
	
	/** The scale. */
	private double scale;
	
	/**
	 * Sets up a new AnimalLayer.
	 *
	 * @param c the c
	 */
	public AnimalLayer(Class<T> c) {
		setSize(Model.getHeight(),Model.getWidth());
		setOpaque(false);
		try {
			t = c.newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Check if the DynamicGridItem is in this layer.
	 *
	 * @param d the DynamicGridItem we are checking
	 * @return true, if successful
	 */
	private boolean inThisLayer(DynamicGridItem d)
	{	// if item's superclass (LandAnimal, FlyingAnimal, etc.) is the type of class passed in (LandAnimal.class, etc.) OR if the item is performing the default action for this layer, return true
		return (d.getClass().getSuperclass().equals(t.getClass()) || d.getAction() == t.getDefaultAction());
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	@Override
    public void paintComponent(Graphics g) {
		int itemX, itemY, itemW=256, itemH=256;
		BufferedImage[] tba;
		super.paintComponent(g);
		Graphics2D g2D = (Graphics2D) g;
		setRenderingHints(g2D);
		try {
			for(DynamicGridItem item : Model.getItems()){	
				if (inThisLayer(item)){
					//itemX = (item.getXCoord()-500)/15-(128*item.getSize()/100);
					//itemY = (item.getYCoord()-500)/15-(128*item.getSize()/100);
						pics = NewImageLibrary.getImage(item);
						if (pics != null) {
							BufferedImage img = pics[item.getPicIndex()%item.getFrames()];
							AffineTransform xform = AffineTransform.getScaleInstance(scale, scale);
							AffineTransformOp op = new AffineTransformOp(xform, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
							img = op.filter(img, null);
							g2D.drawImage(img,(int)((item.getXCoord()/10)*scale),(int)((item.getYCoord()/10)*scale),this);
							//g2D.drawImage(img,(item.getXCoord()-500)/15-(128*item.getSize()/100),(item.getYCoord()-500)/15-(128*item.getSize()/100), null);
							if(item.getShowLabel() || View.getShowLabels()) {
								g2D.setFont(new Font("Arial", Font.PLAIN,(int)(15*scale)));
								g2D.setColor(Color.white);
								g2D.drawString(item.toString() + item.getNewAction(), (int)((item.getXCoord()/10)*scale),(int)((item.getYCoord()/10)*scale));
							}
						}
				}
			}
			g2D.setColor(Color.blue);
			for(DynamicGridItem item : Model.deathQueue){
				itemX = (int)((item.getXCoord()/10)*scale);
				itemY = (int)((item.getYCoord()/10)*scale);
				if (inThisLayer(item)){
					tba = NewImageLibrary.getImage(item);
					if(tba != null) {
					BufferedImage deathImage = tba[0];
					AffineTransform xform = AffineTransform.getScaleInstance(scale, scale);
					AffineTransformOp op = new AffineTransformOp(xform, AffineTransformOp.TYPE_NEAREST_NEIGHBOR);
					deathImage = op.filter(deathImage, null);
					g2D.drawImage(deathImage, (int)((item.getXCoord()/10)*scale),(int)((item.getYCoord()/10)*scale), null);
					itemW = deathImage.getWidth();
					itemH = deathImage.getHeight();
					} 
					g2D.setColor(Color.red);
					// draw x
					g2D.setStroke(new BasicStroke(2));
					g2D.drawLine(itemX+itemW/4, itemY+itemH/4, itemX + itemW/2, itemY + itemH/2);
					g2D.drawLine(itemX + itemW/2, itemY+itemH/4, itemX + itemW/4, itemY + itemH/2);
					if(item.getShowLabel() || View.getShowLabels()) {
						g2D.setFont(new Font("Arial", Font.PLAIN,(int)(15*scale)));
						g2D.drawString(item.toString() + item.getNewAction(), (int)((item.getXCoord()/10)*scale),(int)((item.getYCoord()/10)*scale));
					}
				}
			}
		} catch (ConcurrentModificationException e) {  
           // System.out.println("Something is being modified so we cant display it, wait a cycle");
        }  
	}
	
	/**
	 * Sets the rendering hints for anti-aliasing.
	 *
	 * @param g the new rendering hints
	 */
	public static void setRenderingHints(Graphics2D g) {
    	// turn on anti-aliasing
    	g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    	RenderingHints.VALUE_ANTIALIAS_ON);
    	g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
    	RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    	g.setRenderingHint(RenderingHints.KEY_RENDERING,
    	RenderingHints.VALUE_RENDER_QUALITY);
	}

	/**
	 * Sets the scale.
	 *
	 * @param newScale the new scale
	 */
	public void setScale(double newScale) {
		scale = newScale;
	}
}

