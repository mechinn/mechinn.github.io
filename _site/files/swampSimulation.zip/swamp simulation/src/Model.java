/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.Collection;
import java.util.HashSet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;
import java.awt.Polygon;
import java.util.ArrayList;

/**
 * Model section of MVC, all model calculations start here.
 *
 * @author  group2
 * @author  Michael Chinn <mechinn>
 * @author  Andrea Macartney <andmac>
 * @author  Samuel Schlachter <saschlac>
 * @author  Matthew Puterio <mputerio>
 * @author  Ryan Richardson <rsquared>
 *
 * @version %W% %E%
 *
 * @since   1.6
 */
public class Model{
    
    /** The height. */
    static int height;
    
    /** The width. */
    static int width;
    
    /** The i. */
    static int i = 0;
    
    /** The items. */
    private static Collection<DynamicGridItem> items;
    
    /** The birth queue. */
    static public Collection<DynamicGridItem> birthQueue;
    
    /** The death queue. */
    public static Collection<DynamicGridItem> deathQueue;
    
    /** The add queue. */
    private static Collection<DynamicGridItem> addQueue;
	
	/** The Water location. */
	static private Polygon WaterLocation;
	
	/** The Land location. */
	static private Polygon LandLocation;
	
	/** The Other limits. */
	static private Polygon OtherLimits;
	
	/** The tree list. */
	static public ArrayList<Polygon> treeList;

    /**
     * Model Constructor, sets the dimensions of the model.
     *
     * @param nheight    depth of model.
     * @param nwidth the nwidth
     */
    public Model(int nheight, int nwidth){
		height = nheight;
		width = nwidth;
		items = new HashSet<DynamicGridItem>();
		birthQueue = new HashSet<DynamicGridItem>();
		deathQueue = new HashSet<DynamicGridItem>();
		addQueue = new HashSet<DynamicGridItem>();

		// waterlocation
		int[] tempX1 = {1700, 1243, 1246, 1066, 1039, 909, 836, 833, 543, 493, 436, 386, 335, 246, 260, 237, 174, 86, -500, -500, 1700, 1700, 1700};
		int[] tempY1 = {591, 656, 699, 732, 653, 685, 761, 831, 982, 983, 889, 824, 810, 843, 900, 982, 1049, 1090, 1090, 1500, 1500, 699, 599};
		
		// landLocation
		int[] tempX2 = {1354, 1246, 1127, 1062, 1003, 915, 858, 800, 762, 695, 596, 509, 461, 398, 363, 300, 257, 180, 114, 88, 85, 87, 1357, 1352};
		int[] tempY2 = {540, 549, 517, 544, 594, 578, 572, 625, 707, 755, 787, 799, 792, 746, 709, 712, 755, 812, 824, 825, 825, 88, 90, 459};
		
		// tree locations - ugly, isn't it?
		treeList = new ArrayList<Polygon>();
		treeList.add(new Polygon(new int[] {305,300,290,280,270,266,276,289,296,300,317,338,346,355,360,341,345,333,324,319,314,306},
				new int[] {412,391,393,394,382,374,349,331,307,270,272,287,322,357,376,369,391,394,384,403,413,411},22));
		treeList.add(new Polygon(new int[] {47,54,66,66,80,86,106,121,130,124,128,140,129,124,115,109,99,84,80,70,60,47},
				new int[] {439,421,400,389,366,335,335,355,363,401,406,440,441,456,458,443,476,475,442,461,456,440}, 22));
		treeList.add(new Polygon(new int[] {224,224,241,247,225}, new int[] {426,346,346,428,427}, 5));
		treeList.add(new Polygon(new int[] {336,357,383,366,351,334}, new int[] {438,384,388,424,447,441}, 6));
		treeList.add(new Polygon(new int[] {423,423,441,448,425}, new int[] {404,349,348,410,408}, 5));
		treeList.add(new Polygon(new int[] {457,464,480,480,459}, new int[] {388,299,300,391,386}, 5));
		treeList.add(new Polygon(new int[] {404,432,438,412,381,401}, new int[] {281,225,198,196,275,285}, 6));
		treeList.add(new Polygon(new int[] {598,601,616,622,600}, new int[] {358,277,279,358,359}, 5));
		treeList.add(new Polygon(new int[] {605,620,644,621,603}, new int[] {230,183,186,241,232}, 5));
		treeList.add(new Polygon(new int[] {692,683,697,713,692}, new int[] {312,232,226,312,312}, 5));
		treeList.add(new Polygon(new int[] {778,779,795,799,780}, new int[] {346,289,289,349,347}, 5));
		treeList.add(new Polygon(new int[] {767,784,798,807,855,839,866,861,845,848,836,823,817,806,803,795,768},
				new int[] {247,212,175,141,172,209,238,253,247,266,267,276,288,285,255,266,248}, 17));
		treeList.add(new Polygon(new int[] {949,948,963,970,948}, new int[] {129,52,50,133,130}, 5));
		treeList.add(new Polygon(new int[] {1215,1197,1208,1219,1233,1254,1278,1269,1292,1316,1332,1348,1349,1355,1329,1311,1298,1216,1202},
				new int[] {561,526,522,548,555,539,538,522,517,549,543,543,560,578,597,585,590,566,531}, 19));
		treeList.add(new Polygon(new int[] {948,957,982,966,968,951}, new int[] {685,646,646,654,692,691}, 6));
		treeList.add(new Polygon(new int[] {508,532,546,544,562,540,543,504}, new int[] {527,449,438,461,450,475,534,526}, 8));
		treeList.add(new Polygon(new int[] {223,191,211,233,264,300,323,351,339,285,241,218}, 
				new int[] {600,578,547,559,553,542,543,543,571,590,593,599}, 12));
		
		// alter locations loop
		for (int i = 0; i < treeList.size(); i++){
			for(int j = 0; j < treeList.get(i).npoints; j++){
	    		treeList.get(i).xpoints[j]=(int)(((treeList.get(i).xpoints[j]*1.175)-100)*10+500);
	    		treeList.get(i).ypoints[j]=(int)(((treeList.get(i).ypoints[j]*1.21)-130)*10+500);
	    	}
		}
		
		// everything else's location
		int[] tempX3 = {91,1357,1355,90};
		int[] tempY3 = {92,93,1360,1360};

		for(int i = 0; i<23;++i) {
    		tempX1[i]=(int)(((tempX1[i]*1.175)-100)*10+500);
    		tempY1[i]=(int)(((tempY1[i]*1.21)-130)*10+500);
    	}
		for(int i = 0; i<24;++i) {
    		tempX2[i]=(int)(((tempX2[i]*1.175)-100)*10+500);
    		tempY2[i]=(int)(((tempY2[i]*1.21)-130)*10+500);
    	}
		for(int i = 0; i<4;++i) {
    		tempX3[i]=(int)(((tempX3[i]*1.175)-100)*10+500);
    		tempY3[i]=(int)(((tempY3[i]*1.21)-130)*10+500);
    	}

		WaterLocation = new Polygon(tempX1,tempY1,23);
		LandLocation = new Polygon(tempX2,tempY2,24);
		OtherLimits = new Polygon(tempX3,tempY3,4);

    }

    /**
     * Gets the water location.
     *
     * @return the water location
     */
    public static Polygon getWaterLocation() { return WaterLocation; }
    
    /**
     * Gets the land location.
     *
     * @return the land location
     */
    public static Polygon getLandLocation() { return LandLocation; }
    
    /**
     * Gets the tree list.
     *
     * @return the tree list
     */
    public static ArrayList<Polygon> getTreeList() { return treeList; }
    
    /**
     * Add item to the model's collection of items.
     *
     * @param	item    DynamicGridItem to be added to the model.
     *
     * @return	true if added to items, false if not
     */
    public static boolean addItem(DynamicGridItem item){
		return items.add(item);
//		view.getDisplay().add(new ViewAnimal(iLib,item),new Integer(10));
    }
   
    
    /**
     * Adds the to birth queue.
     *
     * @param item the item
     * @return true, if successful
     */
    public static boolean addToBirthQueue(DynamicGridItem item){
		return birthQueue.add(item);
    }
    
    /**
     * Adds the to death queue.
     *
     * @param item the item
     * @return true, if successful
     */
    public static boolean addToDeathQueue(DynamicGridItem item){
		return deathQueue.add(item);
    }
    
	/**
	 * Gets the water loc.
	 *
	 * @return the water loc
	 */
	public static Polygon getWaterLoc(){return WaterLocation;}
	
	/**
	 * Gets the land loc.
	 *
	 * @return the land loc
	 */
	public static Polygon getLandLoc(){return LandLocation;}
	
	/**
	 * Gets the other limits.
	 *
	 * @return the other limits
	 */
	public static Polygon getOtherLimits(){return OtherLimits;}
	
	/**
	 * Gets the items.
	 *
	 * @return the items
	 */
	public static Collection<DynamicGridItem> getItems(){return items;}
	
	/**
	 * Save swamp.
	 *
	 * @param f the f
	 * @return true, if successful
	 */
	public static boolean saveSwamp(File f)
	{
		if(!f.getName().endsWith(".swamp")) f = new File(f.toString() + ".swamp");
		int size = items.size();
		System.out.println("Saving swamp to: " + f.toString());
		FileOutputStream fos = null;
		ObjectOutputStream out = null;
		try {
			fos = new FileOutputStream(f);
			out = new ObjectOutputStream(fos);
			out.writeObject(new Integer(size));
			out.writeObject(new Long(Controller.getAge()));
			for(DynamicGridItem d : items) out.writeObject(d);
			out.close();
		} catch(IOException ex) { ex.printStackTrace(); return false;}
		return true;
	}
	
	/**
	 * Load swamp.
	 *
	 * @param f the f
	 * @return true, if successful
	 */
	public static boolean loadSwamp(File f)
	{
		Collection<DynamicGridItem> fileItems = new HashSet<DynamicGridItem>();
		System.out.println("Loading swamp from: " + f.toString());
		if(!f.getName().endsWith(".swamp")) { System.out.println("Can only load .swamp files!"); return false; }
		
		FileInputStream fis = null;
		ObjectInputStream in = null;
		
		try {
			fis = new FileInputStream(f);
			in = new ObjectInputStream(fis);
			Integer size = (Integer)in.readObject();
			Controller.setAge((Long)in.readObject());
			for(int i = 0; i < size; i++) {
				fileItems.add((DynamicGridItem)in.readObject());
			}
			in.close();
		} catch(IOException ex) {return false;}
		  catch(ClassNotFoundException ex) {return false;}
		  	if(Controller.isRunning()) {
		  		setAddQueue(fileItems);
		  		Controller.setClearModel(true);
		  		View.repaint();
		  	} else {
		  		doClear();
		  		items.addAll(fileItems);
		  	}
		return true;
	}
	
	public static int countAnimal(String type)
	{
		int rv = 0;
		for(DynamicGridItem d : items) 
			if(d.getTypecode().equals(type)) rv++;
		return rv;
	}
	
	public static int totalAnimals()
	{
		return items.size();
	}
	
	public static int totalSpecies()
	{
		int sc = 0;
		@SuppressWarnings("rawtypes")
		Class[] ani = Setup.getAnimals();
		for(int i = 0; i < ani.length; i++)
			if(getRandomItem(ani[i].getName()) != null) sc++;
		return sc;
	}
	
	public static int countRecentlyDied()
	{
		return deathQueue.size();
	}
	
	public static int countMating()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d.getReproducing()) rv++;
		return rv;
	}
	
	public static int countHungry()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d.getHungry()) rv++;
		return rv;
	}
	
	public static int countAttacking()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d.getAttacking()) rv++;
		return rv;
	}
	
	public static int countWandering()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d.isWandering()) rv++;
		return rv;
	}
	
	public static int countLandAnimals()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d instanceof LandAnimal) rv++;
		return rv;
	}
	
	public static int countWaterAnimals()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d instanceof WaterAnimal) rv++;
		return rv;
	}
	
	public static int countFlyingAnimals()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d instanceof FlyingAnimal) rv++;
		return rv;
	}
	
	public static int countAmphiAnimals()
	{
		int rv = 0;
		for(DynamicGridItem d : items)
			if(d instanceof AmphibiousAnimal) rv++;
		return rv;
	}
	
	/**
	 * Do clear.
	 */
	public static void doClear()
	{
		items.clear();
		deathQueue.clear();
		birthQueue.clear();
	}
	
	/**
	 * Sets the adds the queue.
	 *
	 * @param aq the new adds the queue
	 */
	public static void setAddQueue(Collection<DynamicGridItem> aq)
	{
		addQueue = aq;
	}
	
	/**
	 * Do add queue.
	 *
	 * @return true, if successful
	 */
	public static boolean doAddQueue()
	{
		boolean result = items.addAll(addQueue);
		addQueue.clear();
		return result;
	}
	
	/**
	 * Clear and add.
	 */
	public static void clearAndAdd()
	{
		doClear();
		doAddQueue();
	}
	
	/**
	 * Gets the random item.
	 *
	 * @return the random item
	 */
	public static DynamicGridItem getRandomItem()
	{
		int i = 0;
		int r = new Random().nextInt(items.size());
		for(DynamicGridItem d : items)
		{
			if(i==r) return d;
			i++;
		}
		return null; // should never get here
	}
	
	public static DynamicGridItem getRandomItem(String type)
	{
		Collection<DynamicGridItem> ni = new HashSet<DynamicGridItem>();
		for(DynamicGridItem d : items) {
			if(d.getTypecode().equals(type)) ni.add(d);
		}
		int i = 0;
		if(ni.size() == 0) return null;
		int r = new Random().nextInt(ni.size());
		for(DynamicGridItem d : ni) {
			if(i==r) return d;
			i++;
		}
		return null;
	}
	
	public static void makeExtinct(String type)
	{
		for(DynamicGridItem d : items)
			if(d.getTypecode().equals(type)) addToDeathQueue(d);
		View.repaint();
	}
	
	public static void nukeSwamp()
	{
		for(DynamicGridItem d : items)
			addToDeathQueue(d);
		View.repaint();
	}
	
	/**
	 * Gets the width.
	 *
	 * @return the width
	 */
	public static int getWidth() { return width; }
	
	/**
	 * Gets the height.
	 *
	 * @return the height
	 */
	public static int getHeight() { return height; }
}