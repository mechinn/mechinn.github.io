/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * Creates a JFrame with which we can set initial variables for the swamp
 * </br>Can be initialized by a few ways with runtime variables or loading a swamp file.
 *
 * @author  group2
 * @author  Michael Chinn <mechinn>
 * @author  Andrea Macartney <andmac>
 * @author  Samuel Schlachter <saschlac>
 * @author  Matthew Puterio <mputerio>
 * @author  Ryan Richardson <rsquared>
 * @version %W% %E%
 * @since   1.6
 * @see ActionListener
 */
public class Setup implements ActionListener {
	//  ***** ANIMALS TO SET UP *********************************
	@SuppressWarnings("rawtypes")
	private static Class[] animals = 
	{
		Bee.class,
		Algae.class,
		Grass.class,
		Alligator.class,
		Bullfrog.class,
		Butterfly.class,
		Catfish.class,
		Fly.class,
		Heron.class,
		Mosquitoes.class,
		Moth.class,
		Mouse.class,
		Nutriarat.class,
		Perch.class,
		Raccoon.class,
		Salamander.class,
		Slug.class,
		Snake.class,
		Tadpole.class,
		Treefrog.class,
		Turtle.class,
		Opossum.class,
		Flower.class,
		Crayfish.class,
		Duck.class,
	};
	//  *********************************************************
	
	/** The setup window. */
	private JFrame setupWindow;
	
	/** The grid. */
	private JPanel grid;
	
	/** Is setup done?. */
	private boolean isdone;
	
	/** Animal spinner array for setup box. */
	JSpinner asa[];
	
	/** Animal JLabel array for setup box. */
	JLabel ala[];
	
	/** Animal default values. */
	int dval[];
	
	/** "all num" JSpinner, the one that adds stuff to every animal's box. */
	JSpinner AllNum;	
	
	/** Label for the "to all" box. */
	JLabel AllLabel;
	
	/** "+" button that adds the value from the "to all" box to each animal's box */
	JButton addButton;
	
	/** "-" button that subtracts the value from the "to all" box from each animal's box */
	JButton subButton;
	
	/** The start button. */
	JButton startButton;
	
	/** The load SWAMP file button. */
	JButton loadButton;
	
	/** The clear values button. */
	JButton clearButton;
	
	/** getter for animals array */
	@SuppressWarnings("rawtypes")
	public static Class[] getAnimals()
	{
		return animals;
	}
	
	/** getter for animals array.  exclusion is an array of strings of class names that shouldn't be in the returned array */
	@SuppressWarnings("rawtypes")
	public static Class[] getAnimals(String[] exclusion)
	{
		Class[] newanimals;
		int ni=0, nit=0;
		for(int i = 0; i < animals.length; i++)
			if(!in_array(exclusion, animals[i].getName())) nit++;
		newanimals = new Class[nit];
		for(int i = 0; i < animals.length; i++)
			if(!in_array(exclusion, animals[i].getName())) { newanimals[ni] = animals[i]; ni++; }
		return newanimals;
	}
	
	/** helper method to see if something's in an array */
	private static boolean in_array(String[] arr, String text)
	{
		for(int i = 0; i < arr.length; i++)
		{
			if(arr[i].equals(text)) return true;
		}
		return false;
	}
	

	/**
	 * Return index value given an animal name.  index value applies to arrays of the labels, jspinners, and default values
	 *
	 * @param animal class name
	 * @return index value
	 */
	private int animalIndex(String an)
	{
		for(int i = 0; i < animals.length; i++) if(an.equals(animals[i].getName())) return i;
		return -1;
	}
	
	/**
	 *  pseudo constructor... to limit copy/pasting code in the two constructors
	 */
	private void setupInit()
	{
		isdone = false;
		asa = new JSpinner[animals.length];
		ala = new JLabel[animals.length];
		dval = new int[animals.length];
		
		for(int i = 0; i < animals.length; i++) dval[i] = 0;
	}
	
	/**
	 * Instantiates a new setup (default)
	 */
	public Setup(){
		setupInit();
		setupWindow();
	}
	
	/**
	 * Instantiates a new setup given a map of default values
	 *
	 * @param m Map of default values
	 */
	public Setup(Map<String,Integer> m){
		setupInit();
		int ai;
		for(String ani : m.keySet()) {
			ai = animalIndex(ani);
			System.out.println("getting ai = " + ai + " for " + ani);
			if(ai >= 0) dval[ai] = m.get(ani);
		}
		setupWindow();
	}
	
	/**
	 * Create and display setup window
	 */
	void setupWindow() {
		setupWindow = new JFrame("CISC 275 Group 2 - Setup");
		setupWindow.setLayout(new BorderLayout());
		setupWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		grid = new JPanel();
		grid.setLayout(new GridLayout(0,10)); //**keep rows set to 0 here so that it is dynamic
		
		
		for(int i=0; i < animals.length; i++) {
			ala[i] = new JLabel(animals[i].getName());
			asa[i] = new JSpinner(new SpinnerNumberModel(dval[i],0,100,1));
			grid.add(ala[i]);
			grid.add(asa[i]);
		}
		
	
		AllLabel = new JLabel("FOR ALL: ");
		grid.add(AllLabel);
		AllNum = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
		grid.add(AllNum);
		
		JPanel addsubpanel = new JPanel(new GridLayout(1,2));
		
		addButton = new JButton("+");
		addsubpanel.add(addButton);
		addButton.addActionListener(this);
		
		subButton = new JButton("-");
		addsubpanel.add(subButton);
		subButton.addActionListener(this);
		
		grid.add(addsubpanel);
		
		setupWindow.add("Center",grid);
		
		JPanel bottomButtons = new JPanel();
		bottomButtons.setLayout(new FlowLayout());
		
		clearButton = new JButton("Clear Values");
		bottomButtons.add(clearButton);
		clearButton.addActionListener(this);
		
		loadButton = new JButton("Load SWAMP File");
		bottomButtons.add(loadButton);
		loadButton.addActionListener(this);
		
		startButton = new JButton("Start");
		bottomButtons.add(startButton);
		startButton.addActionListener(this);
		
		setupWindow.add("South",bottomButtons);
		
		setupWindow.setSize(900,220);
		setupWindow.setVisible(true);
	}
	
	/**
	 * Add animals to the model
	 */
	@SuppressWarnings("unchecked")
	private void setupModel() {
		setupWindow.setVisible(false);
	
		for(int i = 0; i < animals.length; i++)
		{
			for(int j = 0; j < (Integer)(asa[i].getValue()); j++) {
					try {
						try {
							Model.addItem((DynamicGridItem)animals[i].getConstructor(int.class, int.class).newInstance(0,0));
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (InstantiationException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							e.printStackTrace();
						}
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}
			}
		}
	  
			isdone = true;
	}
	
	/**
	 * getter for 'done' (are we done?)
	 *
	 * @return done value
	 */
	public boolean done() { return isdone; }
	
	/**
	 * Load swamp from file. (button calls this method)
	 */
	private void loadSwampFromFile()
	{
		setupWindow.setVisible(false);
		boolean r = swampFromFile(setupWindow);
		if(r) { 
			isdone = true;
		} else { setupWindow.setVisible(true); }
	}
	
	/**
	 * Swamp from file. this calls the model method that actually does the loading.  this is called from the above method
	 *
	 * @param frame parent frame for the "couldn't load swamp file" box
	 * @return true if we could load, false if not
	 */
	public static boolean swampFromFile(JFrame frame)
	{
		JFileChooser fc = new JFileChooser();
		fc.addChoosableFileFilter(new FileNameExtensionFilter("SWAMP Files","swamp"));
		fc.setAcceptAllFileFilterUsed(false);
		int rv = fc.showOpenDialog(frame);
		if(rv == JFileChooser.APPROVE_OPTION) {
			File f = fc.getSelectedFile();
			boolean sl = Model.loadSwamp(f);
			if(!sl) { JOptionPane.showMessageDialog(frame, "Couldn't load swamp from " + f.getName() + "!", "Swamp Load Error", JOptionPane.ERROR_MESSAGE); return false;}
			return true;
		}
		return false;
	}
	
	
	/**
	 * Save swamp to file. Not called in setup, but i figured this was a good place to put it
	 *
	 * @param frame the frame
	 * @return true, if successful
	 */
	public static boolean swampToFile(JFrame frame)
	{
		final JFileChooser fc = new JFileChooser();
		fc.addChoosableFileFilter(new FileNameExtensionFilter("SWAMP Files","swamp"));
		fc.setAcceptAllFileFilterUsed(false);
		int rv = fc.showSaveDialog(frame);
		if(rv == JFileChooser.APPROVE_OPTION) {
		File f = fc.getSelectedFile();
		boolean ss = Model.saveSwamp(f);
		if(!ss) { JOptionPane.showMessageDialog(frame, "Couldn't save swamp to " + f.getName() + "!", "Swamp Save Error", JOptionPane.ERROR_MESSAGE); return false; }
		return true;
		}
		return false;
	}
	/**
     * Listener for buttons.  perform any button click actions
     *
     * @param	e    ActionEvent caused by button pressed.
     */
    public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if(source==startButton) {
			setupModel();
		}
		if(source==loadButton) {
			loadSwampFromFile();
		}
		if(source==addButton) {
		for(int i = 0; i < animals.length; i++) { asa[i].setValue((Integer)asa[i].getValue() + (Integer)AllNum.getValue()); }
		AllNum.setValue(1);
		}
		if(source==subButton) {
			for(int i = 0; i < animals.length; i++) { if((Integer)asa[i].getValue() - (Integer)AllNum.getValue() >= 0) asa[i].setValue((Integer)asa[i].getValue() - (Integer)AllNum.getValue()); }
			AllNum.setValue(1);
		}
		if(source==clearButton) {
			for(int i = 0; i < animals.length; i++) { asa[i].setValue(0); }
			AllNum.setValue(1);			
		}
    }
}
