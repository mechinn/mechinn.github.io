/*
 * %W% %E%
 * 
 * Copyright
 * Group 2
 * CISC 275 Spring 2011
 * 
 * This file is part of CISC275s11g2Proj.
 * 
 * CISC275s11g2Proj is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CISC275s11g2Proj is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with CISC275s11g2Proj.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * To those grading: Bullfrog and Treefrog have the same code
 * the mating/birthing behavior of frogs was defined at the last 
 * minute. Ideally a middle Frog class would exist to make 
 * things cleaner but we ran out of time. As they always say
 * every project you code should be done twice, so you know what
 * you're doing the second time around.
 * 
 * Sincerely,
 * 		Group 2
 */

/**
 * Specific AmphibiousAnimal subclass for model.
 *
 * @author  group2
 * @author  Andrea Macartney <andmac>
 * @author  Matthew Puterio <mputerio>
 * @author  Michael Chinn <mechinn>
 * @author  Ryan Richardson <rsquared>
 * @author  Samuel Schlachter <saschlac>
 * @version %W% %E%
 * @since   1.6
 * @see     AmphibiousAnimal
 */
public class Bullfrog extends AmphibiousAnimal{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -380199432350310784L;

	/** The speed. */
	private static int speed = 3;
	
	/** The scale. */
	private static int scale = 15;
	
	/** The counter. */
	private static int counter = 0;
	
	/** The repro rate. */
	private static int reproRate = 5;
	
	/** The lifespan. */
	private static int lifespan = 7500;
	
	/** The carrying child.  - set when a frog is headed to the water to give birth*/
	private boolean carryingChild;

	/**
	 * Instantiates a new bullfrog.
	 *
	 * @param X the x
	 * @param Y the y
	 */
	public Bullfrog(int X, int Y){
		super(counter++,X,Y,speed,scale);
		carryingChild = false;
		favoriteFoods.add("Fly");
		favoriteFoods.add("Bee");
		favoriteFoods.add("Mosquitoes");
		favoriteFoods.add("Butterfly");
		favoriteFoods.add("Moth");
	}

	/* (non-Javadoc)
	 * @see DynamicGridItem#getreproRate()
	 */
	public int getreproRate(){ return reproRate;}
	
	/**
	 * Sets the repro rate.
	 *
	 * @param reproIn the new repro rate
	 */
	public static void setreproRate(int reproIn){reproRate = reproIn;}
	
	/* (non-Javadoc)
	 * @see DynamicGridItem#isCarryingChild()
	 */
	public boolean isCarryingChild(){return carryingChild;}
	
	/* (non-Javadoc)
	 * @see DynamicGridItem#getLifespan()
	 */
	public int getLifespan(){return lifespan;}

	/**
	 * Frogs will only give birth if they're carrying child
	 * 
	 * @see DynamicGridItem#reproduce()
	 */
	public void reproduce(){
		if(carryingChild){
			Model.addToBirthQueue(new Tadpole(this.getXCoord(),this.getYCoord(),this.getTypecode()));
			carryingChild = false;
			resetHungry();
			System.out.println("a Tadpole is born");
		}
	}
	
	/**
	 * sets up the special case of frogs going to the water to give birth
	 * @see DynamicGridItem#changeGoal()
	 */
	public void changeGoal(){
		if(carryingChild){
			int x = 0,y = 0;
			System.out.println(this + " trying to get to the water so my child will be safe");
			while(!Model.getWaterLocation().contains(x,y)){
				x = DynamicGridItem.genRand(15000);
				y = DynamicGridItem.genRand(15000);
			}
			this.setGoal(x,y);
			updateLabelText();
			nextMove();
			this.setActionCounter(-1);
		}
		else{
			super.changeGoal();
		}
	}

	/** Special case for frogs - they give birth when they meet their goal if they're carrying child
	 * @see DynamicGridItem#startGoalEvent()
	 */
	public void startGoalEvent(){
		if(carryingChild){
			reproduce();
		}
		else{
			super.startGoalEvent();
		}
	}

	/**	special case to reset the child flag
	 * @see DynamicGridItem#resetChasingMate()
	 */
	public void resetChasingMate(){
		super.resetChasingMate();
		carryingChild = true;
	}
}
