CISC 275
Spring 2011
Swamp Simulation Project
Group 2

Andrea Macartney <andmac>
Matthew Puterio <mputerio>
Michael Chinn <mechinn>
Ryan Richardson <rsquared>
Samuel Schlachter <saschlac>

Possible Program Arguments:
debug - built in default parameters.
CSV filename - reads in CSV and auto sets setup dialog with values.
<none> - launches a setup dialog for the user to initialize simulation items.

Menu Button:
Brings up main menu, also main menu can be open and closed with the escape key.

Save Swamp:
From main menu when simulation is running there is an option to "save swamp".

Load Swamp:
From setup dialog or while a simulation is running the user can load swamp file
to go back to the exact instance of the model when the user savesd the simulation.

New Swamp:
Resets the program with original program arguments.

Swamp Statistics:
Gives current statistics of everything in simulation in a separate window.

Play/Pause Button:
Starts/Stops the simulation running.

Hide/Show Labels:
Turns individual item labels on and off to the user's likeing.

Birth Control:
Opens separate window with the following controls:
	Spawn: for each item user can create a randomly placed item of selected 
		type in	the simulation.
	Kill: for each item user can kill a random item of selected type in 
		the simulation.
	Slider: varys the rate of reproduction (in %of time) of that item 
		in the simulation.
	Make Extinct: in the dropdown to the left select an item type
		and press make extinct to kill off all of that item type.
	Nuke Swamp: Kill every item in the swamp.
	
Delay Slider:
Changes the delay of the swamp simulation so it can run faster or slower.

Scale Slider:
Changes how zoomed in the main view of the swamp is.
Can also be changed with the mouse scroll wheel.

Mini-map:
Shows in color coded dots each item in swamp. Color code is the following:
	Pink, variable vegetation(flowers).
	Cyan, Amphibious Animals.
	Green, Land Animals.
	Blue, Water Animals.
	White, Flying Animals.
	Red, Dead Animals.
Also shows a white box of what the main view can see of the overall swamp.
User can use mouse to move main view to selected spot, when mouse is in
	mini-map a yellow box will appear around the mouse which is where the
	main view will change to if the user clicks or drags.

Main view
Items in the simulation are shown to the user in the following layers(from bottom to top):
	1. Water animals.
	2. 50% transparent water.
	3. Land/Amphibious animals.
	4. 20% transparent trees.
	5. Flying animals.
Each item also has an optional label that shows it's identifier with what it is doing.
User can use the scroll wheel to change the scale and user can click and drag
	the mouse to pan the view around the swamp.
	
JUnit 4 testing:
JUnit 4 testing can be run on each of the test files in the tests folder.
Each of these test different key aspects of the project which perform
	computations which affect the model of the program.
	
JavaDocs:
in the doc folder is javadocs generated from all source files.