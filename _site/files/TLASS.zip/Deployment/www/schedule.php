<?php
	//if we submitted the response form
	if(isset($_POST['form'])&&$_POST['form']=="response"){
		include_once 'forbidden/scheduleresponse.php';
	}
	//the html title
	$title = "Schedule";
	//get the header
	include_once 'header.php';
?>
					<h2>Schedule</h2>
					<h4>This is your assistant schedule for the selected semester.</h4>
					<?php 
						//if we have a message print it
						if(isset($message) && $message!="") {
							print($message."<br /><br />");
						}
						//setup the database connection
						include_once 'forbidden/db.php';
						//get the semester select box code
						$page = "schedule";
						include_once 'forbidden/semesterselect.php';
						
						//get all the finalized assignments for the selected semester and user
						$qry="SELECT * FROM finalizedassignments WHERE semester='".$semester."' AND username='".$_SESSION['username']."';";
						//run the query
						$result=mysql_query($qry);
						//Check whether the query was successful or not
						if($result) {
							if(mysql_num_rows($result) > 0) { //if we have any rows
					?>
								<table width="900" border="1">
									<tr>
										<td width='50' >Class ID</td>
										<td width="20" >TA/LA</td>
										<td width='400' >Description</td>
									</tr>
								<?php
										//go through the rows
										while($member = mysql_fetch_assoc($result)){
											print "<tr>";
											print("<td>".$member['id']."</td>");
											//display ta for 1 and la for 0
											if($member['ta']==1){
												print("<td width='20' >TA</td>");
											} else if($member['ta']==0){
												print("<td width='20' >LA</td>");
											}
											print("<td>".$member['description']."</td>");
											print "</tr>";
										}
										mysql_free_result($result);
								?>
								</table>
					<?php
							} else {
								//Create query
								$qry="SELECT * FROM publishedassignments WHERE semester='".$semester."' AND username='".$_SESSION['username']."';";
								//run the query
								$result=mysql_query($qry);
								//track the values we are dealing with
								$values = "";
								//Check whether the query was successful or not
								if($result) {
									if(mysql_num_rows($result) > 0) {
					?>
										<form id="responseForm" name="responseForm" method="post" action="schedule">
											<input type="hidden" name="form" value="response" />
											<table width="900" border="1">
												<tr>
													<td width='50' >Class ID</td>
													<td width="20" >TA/LA</td>
													<td width='400' >Description</td>
													<td width='20' >Accept</td>
													<td>Comment</td>
												</tr>
											<?php
													//for every row
													while($member = mysql_fetch_assoc($result)){
														$values .= $member['num']."-";
														print "<tr>";
														print("<td>".$member['id']."</td>");
														//print ta for 1 and la for 0
														if($member['ta']==1){
															print("<td width='20' >TA</td>");
														} else if($member['ta']==0){
															print("<td width='20' >LA</td>");
														}
														print("<td>".$member['description']."</td>");
														//setup a select drop down for the 3 accept choices
														print "<td width='100px'><select name='".$member['num']."-accept'>";
														//setup the options
														$accept = array(3);
														$accept[0] = "<option value='0'>Not Reviewed</option>";
														$accept[1] = "<option value='1'>Rejected</option>";
														$accept[2] = "<option value='2'>Accepted</option>";
														//select the option selected in the db
														switch ($member['accept']) {
															case 0:
																$accept[0] = "<option selected='selected' value='0'>Not Reviewed</option>";
																break;
															case 1:
																$accept[1] = "<option selected='selected' value='1'>Rejected</option>";
																break;
															case 2:
																$accept[2] = "<option selected='selected' value='2'>Accepted</option>";
																break;
														}
														//print options
														foreach($accept as $key => $value){
															print $value;
														}
														print "</select></td>";
														print "<td><input style='width:100%' maxlength='255' type='text' name='".$member['num']."-comment' value='".$member['comment']."' /></td>";
														print "</tr>";
													}
													mysql_free_result($result);
												//track the rows we care about
												print "<input type='hidden' name='nums' value='".$values."' />"
											?>
											</table>
											<input type="submit" name="Submit" value="Save" />
										</form>
					<?php
									} else {
										//if we didnt get any rows in either table then there are no assignments
					?>
										<h4>No current assignments for for the selected semester.</h4>
					<?php
									}
								}
							}
						}
						mysql_close($link);
					?>
<?php include 'footer.php'; ?>