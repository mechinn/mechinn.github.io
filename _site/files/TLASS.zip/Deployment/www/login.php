<?php 
	include 'forbidden/logout.php';

	if(isset($_POST['form'])&&$_POST['form']=="login"){
		include_once 'forbidden/submitlogin.php';
	}

	$need_login = false;
	$title = "Login";
	include 'header.php';
?>
					<h2>Login</h2>
					<h4>Login to the assistant scheduling system.</h4>
					<?php 
						//if we have a message print it
						if(isset($message) && $message!="") {
							print($message."<br /><br />");
						}
					?>
					<form id="loginForm" name="loginForm" method="post" action="login">
						<input type="hidden" name="form" value="login" />
						<table width="300" border="0" cellpadding="2" cellspacing="0">
							<tr>
								<td width="112"><b>Login</b></td>
								<td width="188"><input name="login" type="text" class="textfield" id="login" /></td>
							</tr>
							<tr>
								<td><b>Password</b></td>
								<td><input name="password" type="password" class="textfield" id="password" /></td>
							</tr>
							<tr>
								<td><a href="/register.php">Register</a></td>
								<td><input type="submit" name="Submit" value="Login" /></td>
							</tr>
						</table>
					</form>
<?php include 'footer.php'; ?>
