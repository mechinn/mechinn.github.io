<?php
	if(!empty($_POST)){
		if (!extension_loaded('ldap')) {
			include_once 'forbidden/registerprofile.php';
		} else {
			include_once 'forbidden/ldapregister.php';
		}
	}
	
	//dont need a login to see this page
	$need_login = false;
	//make the title Register
	$title = "Register";
	//include the header
	include('header.php');
?>
					<h2>Register</h2>
					<h4>Register for the assistant scheduling system.</h4>
					<?php 
						if(isset($message) && $message!="") {
							print($message."<br /><br />");
						}
					?>
					<form id="registerForm" name="registerForm" method="post" action="register">
						<input type="hidden" name="form" value="register" />
						<table width="300" border="0" cellpadding="2" cellspacing="0">
							<tr>
								<td width="100"><b>*Username</b></td>
								<td width="200"><input name="username" type="text" class="textfield" id="username" /></td>
							</tr>
							<tr>
								<td width="100"><b>*Password</b></td>
								<td width="200"><input name="password" type="password" class="textfield" id="password" /></td>
							</tr>
							<!--<tr>
								<td width="100"><b>First Name</b></td>
								<td width="200"><input name="firstname" type="text" class="textfield" id="firstname" /></td>
							</tr>
							<tr>
								<td width="100"><b>Last Name</b></td>
								<td width="200"><input name="lastname" type="text" class="textfield" id="lastname" /></td>
							</tr>-->
							<tr>
								<td width="100"></td>
								<td width="200"><input type="submit" name="Submit" value="Submit" /></td>
							</tr>
						</table>
					</form>
					<br />
					<span>* marks required fields</span>
<?php include_once 'footer.php'; ?>
