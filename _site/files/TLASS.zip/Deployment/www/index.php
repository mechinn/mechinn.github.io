<?php 
	header("Location: schedule.php");
?>