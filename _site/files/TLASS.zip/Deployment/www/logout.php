<?php
	include 'forbidden/logout.php';

	header("Location: login.php");
?>