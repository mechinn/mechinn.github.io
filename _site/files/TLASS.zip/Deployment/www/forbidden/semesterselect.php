						<?php							
							$current = "";
							
							//if we changed the semester
							if(isset($_POST['semester'])) {
								$semester = $_POST['semester'];
							}
							
							//Create query
							$qry="SELECT semester FROM sessions where active=1";
							$result=mysql_query($qry);
							
							//Check whether the query was successful or not
							if($result) {
								while($member = mysql_fetch_assoc($result)){
									//keep track of the current semester
									$current = $member['semester'];
								}
								mysql_free_result($result);
							}
							//if we did not change the semester set it as the current semester
							if(!isset($semester)){
								$semester = $current;
							}
						?>
						<form id="scheduleForm" name="scheduleForm" method="post" action="<?php print $page; ?>">
						<input type="hidden" name="form" value="schedule" />
						<table width="300" border="0" cellpadding="2" cellspacing="0">
							<tr>
								<td><b>Semester: </b></td>
								<td>
									<select name="semester">
										<?php
											//Create query
											//if we are on the schedule just select all the semesters
											if($page=="schedule"){
												$qry="SELECT semester FROM sessions;";
											} else if ($page=="profile"){ //if we are on the profile page do not show the finalized semesters
												$qry="SELECT semester FROM sessions WHERE sessions.semester NOT IN (SELECT DISTINCT semester FROM finalizedassignments);";
											} else { //if we get here i am confused
												die("using the semester selector on an unexpected page");
											}
											$result=mysql_query($qry);
											
											//Check whether the query was successful or not
											if($result) {
												while($member = mysql_fetch_assoc($result)){
													//if the option is the selected semester mark as selected in html
													if($member['semester']==$semester){
														$select = "selected='selected'";
													} else {
														$select = "";
													}
													//if the option is the current semester put a star in front of it
													if($member['semester']==$current){
														$currentString = "*";
													} else {
														$currentString = "";
													}
													print "<option ".$select." value='".$member['semester']."'>".$currentString.$member['semester']."</option>";
												}
												mysql_free_result($result);
											}
										?>
									</select>
								</td>
								<td><input type="submit" name="Submit" value="Change Semester" /></td>
							</tr>
						</table>
					</form>