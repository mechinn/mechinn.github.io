<?php
	if(!isset($_SESSION)){
		session_start();
	}
	//connect to the db
	include_once('forbidden/db.php');
	//track the numbers we are modifying
	$nums = $_POST['nums'];
	//setup message string to user
	$message = "";
	
	//go through the numbers we are modifying
	while(strlen($nums)>1){
		$num = strstr($nums,"-",true);
		$nums = strstr($nums,"-");
		$nums = substr($nums,1,strlen($nums));
	
		//setup update query
		$subquery = "UPDATE publishedassignments SET ";
		//if we have an accept value (we should... its a drop down)
		if(isset($_POST[$num."-accept"])&&(trim($_POST[$num."-accept"]) != '')){
			$subquery .= "accept='".$_POST[$num."-accept"]."', ";
			//if we have a comment if not and we are trying to reject bail
			if(isset($_POST[$num."-comment"])&&(trim($_POST[$num."-comment"]) != '')) {
				$subquery .= "comment='".clean($_POST[$num."-comment"])."', ";
			} else if ($_POST[$num."-accept"]==1){
				$message .= "Cannot reject without reason.<br />";
				continue;
			} else {
				$subquery .= "comment='', ";
			}
		}
		//remove the last comma
		$subquery = substr($subquery,0,-2);
		//mark where based on the number we are dealing with
		$subquery .= " WHERE num='".$num."'; ";
		//run the query
		if(!mysql_query($subquery)) {
			$message .= "Error responding to schedule.<br />";
		} /*else {
			$message .= "Responded to schedule successfully.<br />";
		}*/
	}
	//if we havent told the user anything we succeeded and tell them so
	if($message==""){
		$message .= "Updated profile successfully.<br />";
	}
?>