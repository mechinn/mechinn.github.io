<?php
	if(!isset($_SESSION)){
		session_start();
	}
	//setup database
	include_once('forbidden/db.php');
	
	//track updates
	if(isset($_POST['update'])) {
		$updates = $_POST['update'];
	}
	
	//setup string to display to user
	$message = "";
	
	//fixing time input before it goes in the database
	function fixTime($time,&$message) {
		//check how many colons we have in the time we were given
		if(substr_count($time,":")==2){ //2 means we have hr:min:sec already
				
		} else if(substr_count($time,":")==1){ //1 means we have hr:min, need to presume 0sec
			$time = $time.":00";
		} else if(substr_count($time,":")==0){ //0 means we have hr, need to presume 0min 0sec
			$time = $time.":00:00";
		} else { //we have too many colons... what do we have?!
			$message .= "Row was not saved because the time of ".$time." was invalid.<br />";
			return null;
		}
		//if the user gave us pm add 12 hrs to the time, am will just get cutoff so we dont need to worry about that
		if(substr_count($time,"pm")>0 || substr_count($time,"PM")>0 || substr_count($time,"Pm")>0 || substr_count($time,"P.M")>0 || substr_count($time,"p.m")>0 || substr_count($time,"P.m")>0) {
			$temp = $time;
			$time = intval(strstr($temp,":",true))+12;
			$time .= strstr($temp,":");
		}
		//check to see if they gave a legal time
		$temp = $time;
		while(strlen($temp)>2) {
			$hr = true;
			$num = strstr($temp,":",true);
			$temp = strstr($temp,":");
			$temp = substr($temp,1,strlen($temp));
			if($hr) {
				if(intval($num)>23){
					$message .= "Row was not saved because the time of ".$time." was invalid.<br />";
					return null;
				}
				$hr = false;
			} else {
				if(intval($num)>60 || intval($temp)>60){
					$message .= "Row was not saved because the time of ".$time." was invalid.<br />";
					return null;
				}
			}
		}
		//yay we got to this point, give back a good time
		return $time;
	}
	
	//go through our update ids
	while(strlen($updates)>1){
		$num = strstr($updates,"-",true);
		$updates = strstr($updates,"-");
		$updates = substr($updates,1,strlen($updates));
		//if we have a checked delete then delete the row and nothing more
		if(isset($_POST['UPDATE-delete-'.$num])&&(trim($_POST['UPDATE-delete-'.$num]) != '')){
			$subquery = "DELETE FROM assistantsunavailables WHERE id='".$num."';";
			if(!mysql_query($subquery)) {
				$message .= "Error deleting row.<br />";
			} else {
				$message .= "Deleted row.<br />";
			}
			continue;
		}
		//begin the update query
		$subquery = "UPDATE assistantsunavailables SET ";
		//if we have the day (we should, its a dropdown but error checking is never a bad thing)
		if(isset($_POST['UPDATE-day-'.$num])&&(trim($_POST['UPDATE-day-'.$num]) != '')){
			//start and end day should be the same because we dont care about student's schedules though midnight as that is not during hours, its available to be different if in the future someone did want that
			$subquery .= "startDay='".clean($_POST['UPDATE-day-'.$num])."', ";
			$subquery .= "endDay='".clean($_POST['UPDATE-day-'.$num])."', ";
		} else {
			$message .= "Row was not saved because there was no day.<br />";
			continue;
		}
		// check if we have a start time, if not bail
		if(isset($_POST['UPDATE-startTime-'.$num])&&(trim($_POST['UPDATE-startTime-'.$num]) != '')){
			//cleanup the start time
			$startTime = clean($_POST['UPDATE-startTime-'.$num]);
			$startTime = fixTime($startTime,$message);
			if($startTime==null){
				continue;
			}
			$subquery .= "startTime='".$startTime."', ";
		} else {
			$message .= "Row was not saved because there was no start time.<br />";
			continue;
		}
		// check if we have an end time, if not bail
		if(isset($_POST['UPDATE-endTime-'.$num])&&(trim($_POST['UPDATE-endTime-'.$num]) != '')){
			//cleanup the end time
			$endTime = clean($_POST['UPDATE-endTime-'.$num]);
			$endTime = fixTime($endTime,$message);
			if($endTime==null){
				continue;
			}
			$subquery .= "endTime='".$endTime."', ";
		} else {
			$message .= "Row was not saved because there was no end time.<br />";
			continue;
		}
		// if the start time is greater than or equal to the end time bail
		if(intval($startTime) >= intval($endTime)){
			$message .= "Start time is at the same time of or later than the end time.<br />";
			continue;
		}
		//check if we have a comment, if not bail
		if(isset($_POST['UPDATE-comment-'.$num])&&(trim($_POST['UPDATE-comment-'.$num]) != '')){
			$subquery .= "comment='".clean($_POST['UPDATE-comment-'.$num])."', ";
		} else {
			$message .= "Row was not saved because there was no comment.<br />";
			continue;
		}
		//get rid of the last comma
		$subquery = substr($subquery,0,-2);
		//make these updates where the id is the number we have been basing things off of
		$subquery .= " WHERE id='".$num."'; ";
		//run the query and tell the user there is an error if something bad happened
		if(!mysql_query($subquery)) {
			$message .= "Error updating profile.<br />";
		} /*else {
			$message .= "Updated profile successfully.<br />";
		}*/
	}
	
	//go through the new rows
	for ($i=0;$i<$_POST['insertCount'];$i++){
		//if the user marked this as delete just dont insert it
		if(isset($_POST['INSERT-delete-'.$i])&&(trim($_POST['INSERT-delete-'.$i]) != '')){
			continue;
		}
	
		//setup insert query
		$subquery = "INSERT INTO assistantsunavailables (semester, username, startDay, endDay, startTime, endTime, comment) VALUES ('".$_POST['semester']."', '".$_SESSION['username']."', ";
		//if we have the day (we should, its a dropdown but error checking is never a bad thing)
		if(isset($_POST['INSERT-day-'.$i])&&(trim($_POST['INSERT-day-'.$i]) != '')){
			//start and end day should be the same because we dont care about student's schedules though midnight as that is not during hours, its available to be different if in the future someone did want that
			$subquery .= "'".clean($_POST['INSERT-day-'.$i])."', ";
			$subquery .= "'".clean($_POST['INSERT-day-'.$i])."', ";
		} else {
			$message .= "Row was not saved because there was no day.<br />";
			continue;
		}
		// check if we have a start time, if not bail
		if(isset($_POST['INSERT-startTime-'.$i])&&(trim($_POST['INSERT-startTime-'.$i]) != '')){
			//cleanup the start time
			$startTime = clean($_POST['INSERT-startTime-'.$i]);
			$startTime = fixTime($startTime,$message);
			if($startTime==null){
				continue;
			}
			$subquery .= "'".$startTime."', ";
		} else {
			$message .= "Row was not saved because there was no start time.<br />";
			continue;
		}
		// check if we have a end time, if not bail
		if(isset($_POST['INSERT-endTime-'.$i])&&(trim($_POST['INSERT-endTime-'.$i]) != '')){
			//cleanup the end time
			$endTime = clean($_POST['INSERT-endTime-'.$i]);
			$endTime = fixTime($endTime,$message);
			if($endTime==null){
				continue;
			}
			$subquery .= "'".$endTime."', ";
		} else {
			$message .= "Row was not saved because there was no end time.<br />";
			continue;
		}
		// if the start time is greater than or equal to the end time bail
		if(intval($startTime) >= intval($endTime)){
			$message .= "Start time is at the same time of or later than the end time.<br />";
			continue;
		}
		//check if we have a comment, if not bail
		if(isset($_POST['INSERT-comment-'.$i])&&(trim($_POST['INSERT-comment-'.$i]) != '')){
			$subquery .= "'".clean($_POST['INSERT-comment-'.$i])."', ";
		} else {
			$message .= "Row was not saved because there was no comment.<br />";
			continue;
		}
		//get rid of the last comma
		$subquery = substr($subquery,0,-2);
		//end the insert query
		$subquery .= " ); ";
		//run the query and tell the user there is an error if something bad happened
		if(!mysql_query($subquery)) {
			$message .= "Error updating profile.<br />";
		} /*else {
			$message .= "Updated profile successfully.<br />";
		}*/
	}
	//if everything worked tell the user
	if($message==""){
		$message .= "Updated profile successfully.<br />";
	}
?>