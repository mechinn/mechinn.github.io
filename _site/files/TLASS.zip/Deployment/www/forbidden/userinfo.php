<?php
	//setup db connection
	include_once('forbidden/db.php');
	
	//get info about user based on our id
	$query = "SELECT * FROM webusers WHERE id='".$_SESSION['id']."';";
	//run the query
	$result = mysql_query($query);
	if($result) {
		if(mysql_num_rows($result) > 0) {
			$user = mysql_fetch_assoc($result);
		}
	}
?>