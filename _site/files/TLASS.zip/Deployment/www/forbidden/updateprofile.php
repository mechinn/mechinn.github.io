<?php
	if(!isset($_SESSION)){
		session_start();
	}
	//setup the database connection
	include_once('forbidden/db.php');
	
	//setup update query
	$query = "UPDATE webusers SET ";
	//if user inputted a first name
	if(isset($_POST['first'])&&(trim($_POST['first']) != '')){
		$query .= "firstname='".clean($_POST['first'])."', ";
	}
	//if user inputted a last name
	if(isset($_POST['last'])&&(trim($_POST['last']) != '')){
		$query .= "lastname='".clean($_POST['last'])."', ";
	}
	//if user inputted a password
	if(isset($_POST['password'])&&(trim($_POST['password']) != '')){
		//hash the password with sha-1
		$query .= "password='".sha1(clean($_POST['password']))."', ";
	}
	//if user inputted a username
	if(isset($_POST['username'])&&(trim($_POST['username']) != '')){
		$query .= "username='".clean($_POST['username'])."', ";
	}
	//get rid of the last comma
	$query = substr($query,0,-2);
	//make the query where the id equals the users id
	$query .= " WHERE id='".$_SESSION['id']."'";
	//run the query and tell the user how things went
	if(!mysql_query($query)) {
		$message = "Error updating profile.";
	} else {
		$message = "Updated profile successfully";
	}
?>