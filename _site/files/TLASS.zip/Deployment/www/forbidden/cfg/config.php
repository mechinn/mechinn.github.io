<?php
	//edit these as necessary on your server
	
	// the url/ip of the mysql server
	$host = 'localhost';
	// the username to login to the mysql server
    $user = 'mechinn_group2';
	// the password to login to the mysql server
	$pass = 'r00sen2';
	// the database name on the mysql server
    $dbName = 'mechinn_cisc475';
?>