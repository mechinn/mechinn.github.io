<?php
	//Start session
	if(!isset($_SESSION)){
		session_start();
	}
	
	//Unset the variables stored in session
	unset($_SESSION['id']);
	unset($_SESSION['username']);
?>