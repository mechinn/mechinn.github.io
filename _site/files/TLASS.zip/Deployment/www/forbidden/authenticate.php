<?php
	//Start session
	if(!isset($_SESSION)){
		session_start();
	}
	
	//if we did not set that we need a login mark as true
	if(!isset($need_login)){
		$need_login = true;
	}
	
	//Check whether the session variable SESS_MEMBER_ID is present or not
	if(!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
		//if we need a login
		if($need_login){
			//go to login page
			header("location: login.php");
			exit();
		}
	} else {//mark that we are logged in
		$pass_login = true;
	}
?>