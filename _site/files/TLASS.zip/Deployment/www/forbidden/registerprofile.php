<?php
	if(!isset($_SESSION)){
		session_start();
	}

	//setup db
	include_once('forbidden/db.php');
	//funtion to register, mostly so we can bail if something went wrong
	function register() {
		//setup an array to keep track of what columns we need
		$cols = array();
		//if we have a first name
		if(isset($_POST['firstname'])&&(trim($_POST['firstname']) != '')){
			$cols[] = "firstname";
		}
		//if we have a last name
		if(isset($_POST['lastname'])&&(trim($_POST['lastname']) != '')){
			$cols[] = "lastname";
		}
		//if we have a password, if not bail
		if(isset($_POST['password'])&&(trim($_POST['password']) != '')){
			$cols[] = "password";
		} else {
			return "No password given.";
		}
		//if we have a username, if not bail
		if(isset($_POST['username'])&&(trim($_POST['username']) != '')){
			$username = clean($_POST['username']);
			$qry = "SELECT * FROM webusers WHERE username='".$username."'";
			$result = mysql_query($qry);
			if($result) {
				//if the username already exists in the webusers table
				if(mysql_num_rows($result) > 0) {
					return "Username already used";
				}
			}
			$cols[] = "username";
		} else {
			return "No username given.";
		}
		//build the insert query
		$query = "INSERT INTO webusers (username, password) VALUES (";
		//build the values
		$query .= "'".clean($_POST['username'])."', ";
		$query .= "'".sha1(clean($_POST['password']))."' ";
		//close the query
		$query .= ");";
		//run the query
		if(!mysql_query($query)) {
			return "Error creating profile.";
		} else {
			return "Thank you for registering for the University of Delaware's Assistant Scheduling System.";
		}
	}
	//run the function and get back the message
	$message = register();
	//if we get the success message it worked and we go to the login page
	if($message == "Thank you for registering for the University of Delaware's Assistant Scheduling System.") {
		include_once("login.php");
		exit();
	}
?>
