<?php
	if(!isset($_SESSION)){
		session_start();
	}
	include_once('forbidden/db.php');
	
	//get the row where the user login works
	$query = "SELECT * FROM webusers WHERE username='".clean($_POST['login'])."' AND password='".sha1(clean($_POST['password']))."'";
	//run the query
	$result = mysql_query($query);
	//if it worked
	if($result) {
		//if there is 1 user
		if(mysql_num_rows($result) == 1) {
			//Login Successful
			session_regenerate_id();
			$member = mysql_fetch_assoc($result);
			$_SESSION['id'] = $member['id'];
			$_SESSION['username'] = $member['username'];
			// $_SESSION['firstName'] = $member['firstname'];
			// $_SESSION['lastName'] = $member['lastname'];
			session_write_close();
			//go to schedule.php
			header("location: schedule.php");
			exit();
		} else if(mysql_num_rows($result) > 1) {
			$message = 'multiple users?';//shouldnt ever get here...
		}
	}
	mysql_close($link);
	//Login failed
	$message = "Login failed";
?>