<?php
	if(isset($_POST['form'])&&$_POST['form']=="profile"){
		include_once 'forbidden/updateprofile.php';
	} else if(isset($_POST['form'])&&$_POST['form']=="times") {
		include_once 'forbidden/updatetimes.php';
	}
	//make the title profile
	$title = "Profile";
	//get the header
	include('header.php');
	include('forbidden/userinfo.php');
?>
					<h2>Profile</h2>
					<h4>Welcome<?php if(isset($user['name'])){ print " ".$user['name']; } ?>, this is your current assistant assignment system profile.</h4>
					<?php 
						//if we have a message to print do it
						if(isset($message) && $message!="") {
							print($message."<br />");
						}
					?>
					<div style="float:left;">
						<form id="profileForm" name="profileForm" method="post" action="profile">
							<input type="hidden" name="form" value="profile" />
							<table width="300" border="0" cellpadding="2" cellspacing="0">
								<!--<tr>
									<td width="100"><b>Username</b></td>
									<td width="200"><input name="username" maxlength='255' type="text" class="textfield" id="username" <?php //if(isset($username)){ print "value='".$username."'"; } ?> /></td>
								</tr>-->
								<tr>
									<td width="100"><b>New Password</b></td>
									<td width="200"><input name="password" maxlength='255' type="password" class="textfield" id="password" /></td>
								</tr>
								<tr>
									<td width="100"></td>
									<td width="200"><input type="submit" name="Submit" value="Save" /></td>
								</tr>
							</table>
						</form>
					</div>
					<div style="float:right;">
						<div style="margin-left:140px;" >
							<?php 
								$page = "profile";
								include_once 'forbidden/semesterselect.php'; 
							?>
						</div>
						<script type="text/javascript">
							var count = 0;
							function addRow() {
								//setup html code for a new row
								var html = "<tr>";
								html+="<td><select name='INSERT-day-"+count+"' >";
								html+="<option value='0'>Sunday</option>";
								html+="<option value='1'>Monday</option>";
								html+="<option value='2'>Tuesday</option>";
								html+="<option value='3'>Wednesday</option>";
								html+="<option value='4'>Thursday</option>";
								html+="<option value='5'>Friday</option>";
								html+="<option value='6'>Saturday</option>";
								html+="</select></td>";
								html+="<td><input size='18' type='text' maxlength='11' name='INSERT-startTime-"+count+"' /></td>";
								html+="<td><input size='18' type='text' maxlength='11' name='INSERT-endTime-"+count+"' /></td>";
								html+="<td><input size='18' type='text' maxlength='255' name='INSERT-comment-"+count+"' /></td>";
								html+="<td width='10px'><input type='checkbox' name='INSERT-delete-"+count+"' value='delete' /></td>"
								html+="</tr>";
								// console.log(html);
								//use jquery to add a new row
								$('#times').append(html);
								count++;
							}
							function addInsertCount() {
								//add the rows we added as a hidden input and submit the form
								var html = "<input type='hidden' value='"+count+"' name='insertCount' />";
								$('form#profileForm').append(html);
								$("form#profileForm").submit();
							}
						</script>
						<form id="profileForm" name="profileForm" method="post" action="profile">
							<input type="hidden" name="form" value="times" />
							<input type="hidden" value="<?php print $semester; ?>" name="semester" />
							<table id="times" width="610" border="1" cellpadding="2" cellspacing="0">
								<tr>
									<td width="100px"><b>Day</b></td>
									<td width="100px"><b>Start</b></td>
									<td width="100px"><b>End</b></td>
									<td width="100px"><b>Comment</b></td>
									<td width="10px"><b>Delete</b></td>
								</tr>
								<?php
									//get previous unavailable times
									$qry="SELECT * FROM assistantsunavailables WHERE semester='".$semester."' AND username='".$_SESSION['username']."';";
									//run query
									$result=mysql_query($qry);
									
									//Check whether the query was successful or not
									if($result) {
										//track the ids
										$ids = array();
										while($member = mysql_fetch_assoc($result)){
											$ids[] = $member['id'];
											//create a drop down of days of the week
											$day = array(7);
											$day[0] = "<option value='0'>Sunday</option>";
											$day[1] = "<option value='1'>Monday</option>";
											$day[2] = "<option value='2'>Tuesday</option>";
											$day[3] = "<option value='3'>Wednesday</option>";
											$day[4] = "<option value='4'>Thursday</option>";
											$day[5] = "<option value='5'>Friday</option>";
											$day[6] = "<option value='6'>Saturday</option>";
											//select the day
											switch ($member['startDay']) {
												case 0:
													$day[0] = "<option selected='selected' value='0'>Sunday</option>";
													break;
												case 1:
													$day[1] = "<option selected='selected' value='1'>Monday</option>";
													break;
												case 2:
													$day[2] = "<option selected='selected' value='2'>Tuesday</option>";
													break;
												case 3:
													$day[3] = "<option selected='selected' value='3'>Wednesday</option>";
													break;
												case 4:
													$day[4] = "<option selected='selected' value='4'>Thursday</option>";
													break;
												case 5:
													$day[5] = "<option selected='selected' value='5'>Friday</option>";
													break;
												case 6:
													$day[6] = "<option selected='selected' value='6'>Saturday</option>";
													break;
											}
											print "<tr>";
											print "<td width='100px'><select name='UPDATE-day-".$member['id']."'>";
											foreach($day as $key => $value){
												print $value;
											}
											print "</select></td>";
											print "<td width='100px'><input size='18' type='text' maxlength='11' name='UPDATE-startTime-".$member['id']."' value='".$member['startTime']."'/></td>";
											print "<td width='100px'><input size='18' type='text' maxlength='11' name='UPDATE-endTime-".$member['id']."' value='".$member['endTime']."'/></td>";
											print "<td width='100px'><input size='18' type='text' maxlength='255' name='UPDATE-comment-".$member['id']."' value='".$member['comment']."'/></td>";
											print "<td width='10px'><input type='checkbox' name='UPDATE-delete-".$member['id']."' value='delete' /></td>";
											print "</tr>";
											
										}
										mysql_free_result($result);
										//create a hidden input of the row ids from the db
										print "<input type='hidden' value='";
										foreach($ids as $key => $value){
											print $value."-";
										}
										print "' name='update' />";
									}
								?>
							</table>
							<div style="margin-left:220px;">
								<input type="button" value="Add" onclick="addRow();"/>
								<input type="button" name="Submit" value="Save" onclick="addInsertCount();"/>
							</div>
						</form>
					</div>
<?php 
	mysql_close($link);
	include_once 'footer.php';
?>
