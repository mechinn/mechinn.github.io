<?php 
	//dont need a login on this page
	$need_login = false;
	$title = "About";
	include_once 'header.php';
?>
					<h2>About</h2> 
					<h3>CISC475 Fall 2011 Project</h3>
					<h3>Clients:</h3>
					<ul>
						<li>Dr. Daniel Chester - Associate Chair - Department of Computer and Information Sciences</li>
						<li>Dr. Stephen Siegel - Assistant Professor - Department of Computer and Information Sciences</li>
					</ul>
					<h3>Team 2 - FURPS++</h3>
					<ul>
						<li><strong>Leader: Austin Cory Bart</strong></li>
						<li>Michael Chinn</li>
						<li>Andrea Macartney</li>
						<li>Etornam Banini</li>
						<li>William Greenhalgh</li>
					</ul>
<?php include_once 'footer.php'; ?>