<!DOCTYPE html>
<?php 
	require_once('forbidden/authenticate.php');
?>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<title>UDel's Assistant Webform<?php if(isset($title)){print " | ".$title;} ?></title>
		<meta name="author" content="Team 2: Austin Cory Bart, Michael Chinn, Andrea Macartney, Etornam Banini, William Greenhalgh">
		<link rel="shortcut icon" href="kiwi.ico" />
		<link href="css/style.css" media="screen" rel="stylesheet" type="text/css" />
		<!--[if IE]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<script type="text/javascript" src="scripts/jquery.js"></script>
	</head>
	<body>
		<div id="page">
			<header>
				<div id="header">
					<a class="dynamic" href="/">
						<span id="logo">
							<img src="images/UDPrimaryLogo2945web.jpg" />
						</span>
						<div id="headerText">
							<span id="siteTitle">
								Teaching and Laboratory Assistant
							</span>
							<br />
							<span id="subTitle">
								Scheduling System
							</span>
						</div>
					</a>
					<hr id="headerDivide" />
					<nav id="mainMenu">
						<ul>
							<?php 
								//if we are logged in
								if(isset($pass_login)&&$pass_login==true) {
							?> 
								<li><a class="dynamic" href="schedule.php">Schedule</a></li> 
								<li><a class="dynamic" href="profile.php">Profile</a></li>
								<li><a href="logout.php">Logout</a></li> 
							<?php
								} else {
							?>
								<li><a class="dynamic" href="/">Login</a></li>
							<?php
								}
							?>
							<li><a class="dynamic" href="about.php">About</a></li>
						</ul>
					</nav>
				</div>
			</header>
			<section id="body">
				<div id="wrapper">