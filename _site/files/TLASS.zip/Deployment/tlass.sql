# --------------------------------------------------------
# Host:                         127.0.0.1
# Server version:               5.5.16
# Server OS:                    Win32
# HeidiSQL version:             6.0.0.3603
# Date/time:                    2011-12-07 15:13:34
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

# Dumping database structure for tlass
DROP DATABASE IF EXISTS `tlass`;
CREATE DATABASE IF NOT EXISTS `tlass` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `tlass`;


# Dumping structure for table tlass.assistantsunavailables
DROP TABLE IF EXISTS `assistantsunavailables`;
CREATE TABLE IF NOT EXISTS `assistantsunavailables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semester` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) DEFAULT NULL,
  `startDay` tinyint(4) DEFAULT NULL,
  `startTime` time DEFAULT NULL,
  `endDay` tinyint(4) DEFAULT NULL,
  `endTime` time DEFAULT NULL,
  `comment` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

# Dumping data for table tlass.assistantsunavailables: 0 rows
DELETE FROM `assistantsunavailables`;
/*!40000 ALTER TABLE `assistantsunavailables` DISABLE KEYS */;
/*!40000 ALTER TABLE `assistantsunavailables` ENABLE KEYS */;


# Dumping structure for table tlass.finalizedassignments
DROP TABLE IF EXISTS `finalizedassignments`;
CREATE TABLE IF NOT EXISTS `finalizedassignments` (
  `num` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semester` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) DEFAULT NULL,
  `id` varchar(255) DEFAULT NULL,
  `ta` tinyint(1) unsigned DEFAULT NULL,
  `place` tinyint(3) unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `semester_username_id_ta` (`semester`,`username`,`id`,`ta`),
  KEY `place` (`place`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

# Dumping data for table tlass.finalizedassignments: 0 rows
DELETE FROM `finalizedassignments`;
/*!40000 ALTER TABLE `finalizedassignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `finalizedassignments` ENABLE KEYS */;


# Dumping structure for table tlass.publishedassignments
DROP TABLE IF EXISTS `publishedassignments`;
CREATE TABLE IF NOT EXISTS `publishedassignments` (
  `num` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semester` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) DEFAULT NULL,
  `id` varchar(255) DEFAULT NULL,
  `ta` tinyint(1) unsigned DEFAULT NULL,
  `place` tinyint(3) unsigned DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `accept` tinyint(2) NOT NULL DEFAULT '0',
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `username` (`username`),
  KEY `id` (`id`),
  KEY `ta` (`ta`),
  KEY `place` (`place`),
  KEY `semester` (`semester`)
) ENGINE=MyISAM AUTO_INCREMENT=237 DEFAULT CHARSET=latin1;

# Dumping data for table tlass.publishedassignments: 0 rows
DELETE FROM `publishedassignments`;
/*!40000 ALTER TABLE `publishedassignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `publishedassignments` ENABLE KEYS */;


# Dumping structure for table tlass.sessions
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `semester` varchar(255) NOT NULL,
  `session` blob,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`semester`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

# Dumping data for table tlass.sessions: 0 rows
DELETE FROM `sessions`;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;


# Dumping structure for table tlass.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

# Dumping data for table tlass.users: 1 rows
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`username`, `password`) VALUES
	('admin', 'd033e22ae348aeb5660fc2140aec35850c4da997');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


# Dumping structure for table tlass.webusers
DROP TABLE IF EXISTS `webusers`;
CREATE TABLE IF NOT EXISTS `webusers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

# Dumping data for table tlass.webusers: 0 rows
DELETE FROM `webusers`;
/*!40000 ALTER TABLE `webusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `webusers` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
