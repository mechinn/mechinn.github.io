Teaching and Lab Assistant Scheduling System

CISC475 - Fall 2011

Team 2 - FURPS++
Leader: Austin Cory Bart
Michael Chinn
Andrea Macartney
Etornam Banini
William Greenhalgh

Requirements:
	Server:
		Apache Server
		PHP enabled on Apache
		MySQL php extension
		MySQL Server
	User's computer:
		Java Runtime Environment
	Assistant's computer:
		Modern Web Browser (IE7+, Firefox 3.6+, Chrome, Opera 10+, Safari 5+)
	
Optional:
	Server:
		LDAP php extension

Deployment:
	Webform & Database:
		Install Apache2
		Install PHP for apache2
		Install and enable the MySQL PHP extension
		Install and enable the LDAP PHP extension (optional, webform checks to make sure username is a valid on @udel.edu)
		Install MySQL Server
		Setup SSL Certificate on Apache if a signed one is being used.
		Open port 80, 443 and 3306 in the firewalls protecting the server.
		Place everything from www folder in the root of the Apache webserver (not the root of the filesystem, where https://hostnamehere/ points)
		Run sql command line application and run the following command:
			�@<Directory where kiwi.sql is located>/kiwi.sql�
		Give a user that can connect from any host (%) permissions to do anything to the database created by the .sql file
		Change the settings in /forbidden/cfg/config.php to reflect that of your MySQL setup.
		Restart the server programs and test the webform. If you can register successfully then the server is setup correctly
		
	Java Program:
		Install the Java Runtime Environment
		tlass.jar and connect to your server with the necessary MySQL credentials by going to File->Server Settings
			(this will create a settings file so you do not need to type in the credentials every time you connect)
		